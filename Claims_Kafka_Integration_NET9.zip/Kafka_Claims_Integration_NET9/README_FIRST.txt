CLAIMS KAFKA INTEGRATION - .NET 9

Contents:
- ClaimsKafkaConsumer: independent Windows Worker Service for inbound inventory.
- ClaimsKafkaProducer: independent Windows Worker Service for outbound Outbox events.
- SqlScripts/01_Kafka_Integration_Tables.sql: Outbox and inbound poison-message error table.
- VB.NET_Outbox_Insert_Example.sql: illustrative Outbox insert pattern.
- Outbound_Payload_Template.json: complete sample envelope with blank optional values.

IMPORTANT BEFORE DEPLOYMENT
1. Replace placeholders in each appsettings.json with approved environment values.
2. Set Kafka private-key password through a protected environment variable:
   Kafka__SslKeyPassword
3. The password was present in the uploaded configuration in plaintext. Rotate it before deployment.
4. Run the SQL script in the correct database.
5. Confirm the exact client outbound contract and whether each optional field accepts empty string or null.
6. Confirm dbo.UDT_CliffsKFCWaffles_Api and dbo.Usp_TestApiCrud exist as shown in the supplied Chat doc.
7. Confirm the Windows service account has SQL access and read access to the certificate files.
8. Set Windows Service recovery to restart on failure.

DESIGN NOTES
- Existing dbo.CliffsKFCWaffles_Api and dbo.WCRPaymentLog are not altered.
- Consumer calls dbo.Usp_TestApiCrud with dbo.UDT_CliffsKFCWaffles_Api.
- The TVP's Id column is supplied as 0 because it is NOT the destination identity column and the supplied SP ignores it.
- Existing same-day ICN duplicate handling remains in the stored procedure.
- Consumer commits offsets only after SQL persistence; malformed messages are written to the SQL error table before commit.
- Producer sends raw Outbox Payload and waits for Kafka acknowledgement before marking SENT.
- Outbox insert must be part of the same transaction as the final WCRPaymentLog update.
- Producer FAILED rows require manual review/requeue; no dead-letter topic exists.
- At-least-once delivery is used. A duplicate is possible if the process crashes after Kafka acknowledgement but before marking the Outbox row SENT. Use EventId for downstream deduplication where supported.

BUILD
Open each project folder separately and run:
  dotnet restore
  dotnet build -c Release
  dotnet publish -c Release -r win-x64 --self-contained false

The projects target net9.0.

OUTBOUND TEMPLATE
Outbound_Payload_Template.json keeps the sample envelope keys present. It is a structural template, not confirmation that the client accepts every blank/null value. Confirm required fields and empty-value semantics with the client before production. The Producer publishes the exact Payload string stored in SQL.
