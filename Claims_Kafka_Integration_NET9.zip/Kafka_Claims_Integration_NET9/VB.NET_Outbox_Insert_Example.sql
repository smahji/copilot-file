/*
  Illustrative SQL pattern for your VB.NET automation.
  Execute this insert in the SAME SqlTransaction as the final WCRPaymentLog update.
  Construct @Payload in VB.NET using the client's agreed JSON structure.
*/
DECLARE @EventId UNIQUEIDENTIFIER = NEWID();

INSERT INTO dbo.CliffWaffles_KafkaOutbox
    (EventId, ICN, Payload, KafkaStatus, KafkaSent, KafkaRetryCount, CreatedUtc)
VALUES
    (@EventId, @ICN, @Payload, 'PENDING', 0, 0, SYSUTCDATETIME());

-- Commit the surrounding transaction only after BOTH the WCRPaymentLog update
-- and this Outbox insert have succeeded.
