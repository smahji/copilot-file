/*
  Kafka integration support tables.
  Does NOT alter dbo.CliffsKFCWaffles_Api or dbo.WCRPaymentLog.
*/

IF OBJECT_ID(N'dbo.CliffWaffles_KafkaOutbox', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.CliffWaffles_KafkaOutbox
    (
        OutboxId BIGINT IDENTITY(1,1) NOT NULL CONSTRAINT PK_CliffWaffles_KafkaOutbox PRIMARY KEY,
        EventId UNIQUEIDENTIFIER NOT NULL,
        ICN NVARCHAR(30) NULL,
        Payload NVARCHAR(MAX) NOT NULL,
        KafkaStatus VARCHAR(20) NOT NULL CONSTRAINT DF_CliffWaffles_KafkaOutbox_Status DEFAULT ('PENDING'),
        KafkaSent BIT NOT NULL CONSTRAINT DF_CliffWaffles_KafkaOutbox_Sent DEFAULT (0),
        KafkaRetryCount INT NOT NULL CONSTRAINT DF_CliffWaffles_KafkaOutbox_Retry DEFAULT (0),
        NextRetryUtc DATETIME2(3) NULL,
        LockId UNIQUEIDENTIFIER NULL,
        LockedUntilUtc DATETIME2(3) NULL,
        KafkaSentDate DATETIME2(3) NULL,
        KafkaLastAttemptDate DATETIME2(3) NULL,
        KafkaError NVARCHAR(4000) NULL,
        CreatedUtc DATETIME2(3) NOT NULL CONSTRAINT DF_CliffWaffles_KafkaOutbox_Created DEFAULT (SYSUTCDATETIME()),
        CONSTRAINT UQ_CliffWaffles_KafkaOutbox_EventId UNIQUE (EventId),
        CONSTRAINT CK_CliffWaffles_KafkaOutbox_Status CHECK (KafkaStatus IN ('PENDING','PROCESSING','SENT','FAILED'))
    );

    CREATE INDEX IX_CliffWaffles_KafkaOutbox_Pending
        ON dbo.CliffWaffles_KafkaOutbox (KafkaStatus, NextRetryUtc, OutboxId)
        INCLUDE (EventId, ICN, LockedUntilUtc);
END;
GO

IF OBJECT_ID(N'dbo.CliffsKFCWaffles_KafkaInboxErrors', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.CliffsKFCWaffles_KafkaInboxErrors
    (
        ErrorId BIGINT IDENTITY(1,1) NOT NULL CONSTRAINT PK_CliffsKFCWaffles_KafkaInboxErrors PRIMARY KEY,
        KafkaTopic NVARCHAR(250) NOT NULL,
        KafkaPartition INT NOT NULL,
        KafkaOffset BIGINT NOT NULL,
        RawPayload NVARCHAR(MAX) NOT NULL,
        ErrorMessage NVARCHAR(4000) NOT NULL,
        CreatedUtc DATETIME2(3) NOT NULL CONSTRAINT DF_CliffsKFCWaffles_KafkaInboxErrors_Created DEFAULT (SYSUTCDATETIME()),
        CONSTRAINT UQ_CliffsKFCWaffles_KafkaInboxErrors_Offset UNIQUE (KafkaTopic, KafkaPartition, KafkaOffset)
    );
END;
GO
