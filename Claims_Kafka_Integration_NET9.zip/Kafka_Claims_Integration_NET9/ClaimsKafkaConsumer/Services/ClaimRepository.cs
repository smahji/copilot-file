using System.Data;
using ClaimsKafkaConsumer.Models;
using Microsoft.Data.SqlClient;

namespace ClaimsKafkaConsumer.Services;

public sealed class ClaimRepository : IClaimRepository
{
    private readonly string _connectionString;
    private readonly ILogger<ClaimRepository> _logger;

    public ClaimRepository(IConfiguration configuration, ILogger<ClaimRepository> logger)
    {
        _connectionString = configuration.GetConnectionString("DefaultConnection")
            ?? throw new InvalidOperationException("ConnectionStrings:DefaultConnection is missing.");
        _logger = logger;
    }

    public async Task InsertInventoryAsync(InboundClaim claim, CancellationToken cancellationToken)
    {
        // The existing UDT contains an Id column, but dbo.Usp_TestApiCrud does not use it.
        // Supply 0 for that UDT-only value. SQL Server generates dbo.CliffsKFCWaffles_Api.Id.
        var table = new DataTable();
        table.Columns.Add("Id", typeof(long));
        table.Columns.Add("ICN", typeof(string));
        table.Columns.Add("Payloc", typeof(string));
        table.Columns.Add("Engine", typeof(string));
        table.Columns.Add("OrgID", typeof(string));
        table.Columns.Add("Policy", typeof(string));
        table.Columns.Add("Region", typeof(string));

        table.Rows.Add(
            0L,
            DbValue(claim.InventoryControlNumber),
            DbValue(claim.PayLocation),
            DbValue(claim.PayEngine),
            DbValue(claim.OrganizationId),
            DbValue(claim.PolicyNumber),
            DbValue(claim.ClaimSystemIdentification));

        await using var connection = new SqlConnection(_connectionString);
        await using var command = new SqlCommand("dbo.Usp_TestApiCrud", connection)
        {
            CommandType = CommandType.StoredProcedure,
            CommandTimeout = 60
        };

        var parameter = command.Parameters.Add("@P_CliffsKFCWaffles_Api", SqlDbType.Structured);
        parameter.TypeName = "dbo.UDT_CliffsKFCWaffles_Api";
        parameter.Value = table;

        var output = command.Parameters.Add("@P_Out", SqlDbType.BigInt);
        output.Direction = ParameterDirection.Output;

        await connection.OpenAsync(cancellationToken);
        await command.ExecuteNonQueryAsync(cancellationToken);

        _logger.LogInformation(
            "Inbound inventory persisted. ICN={ICN}; stored-procedure output={Output}",
            claim.InventoryControlNumber,
            output.Value == DBNull.Value ? null : output.Value);
    }

    public async Task SaveRejectedMessageAsync(
        string topic,
        int partition,
        long offset,
        string payload,
        string error,
        CancellationToken cancellationToken)
    {
        const string sql = @"
IF OBJECT_ID(N'dbo.CliffsKFCWaffles_KafkaInboxErrors', N'U') IS NULL
    THROW 51000, 'Run the Kafka integration SQL script to create dbo.CliffsKFCWaffles_KafkaInboxErrors.', 1;

INSERT INTO dbo.CliffsKFCWaffles_KafkaInboxErrors
    (KafkaTopic, KafkaPartition, KafkaOffset, RawPayload, ErrorMessage, CreatedUtc)
SELECT @Topic, @Partition, @Offset, @Payload, @Error, SYSUTCDATETIME()
WHERE NOT EXISTS
(
    SELECT 1
    FROM dbo.CliffsKFCWaffles_KafkaInboxErrors
    WHERE KafkaTopic = @Topic
      AND KafkaPartition = @Partition
      AND KafkaOffset = @Offset
);";

        await using var connection = new SqlConnection(_connectionString);
        await using var command = new SqlCommand(sql, connection);
        command.Parameters.Add("@Topic", SqlDbType.NVarChar, 250).Value = topic;
        command.Parameters.Add("@Partition", SqlDbType.Int).Value = partition;
        command.Parameters.Add("@Offset", SqlDbType.BigInt).Value = offset;
        command.Parameters.Add("@Payload", SqlDbType.NVarChar, -1).Value = payload;
        command.Parameters.Add("@Error", SqlDbType.NVarChar, 4000).Value =
            error.Length > 4000 ? error[..4000] : error;

        await connection.OpenAsync(cancellationToken);
        await command.ExecuteNonQueryAsync(cancellationToken);
    }

    private static object DbValue(string? value) =>
        string.IsNullOrWhiteSpace(value) ? DBNull.Value : value.Trim();
}
