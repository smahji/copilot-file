namespace ClaimsKafkaConsumer.Services;

public interface IClaimRepository
{
    Task InsertInventoryAsync(InboundClaim claim, CancellationToken cancellationToken);
    Task SaveRejectedMessageAsync(
        string topic,
        int partition,
        long offset,
        string payload,
        string error,
        CancellationToken cancellationToken);
}
