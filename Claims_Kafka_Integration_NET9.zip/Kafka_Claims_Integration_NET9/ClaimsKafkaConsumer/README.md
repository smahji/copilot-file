# Claims Kafka Consumer (.NET 9)

Consumes client inventory JSON from the inbound Kafka topic and inserts it using the existing
`dbo.Usp_TestApiCrud` stored procedure and `dbo.UDT_CliffsKFCWaffles_Api` table type.

## Important behavior

- Reads fields from the nested `Request` object.
- Maps `claimSystemIdentification` to SQL `Region`.
- Does not populate `dbo.CliffsKFCWaffles_Api.Id`; SQL Server identity remains responsible for it.
- Supplies `0` for the existing TVP's required `Id` column because the supplied stored procedure does not use that TVP field.
- Commits a Kafka offset only after SQL persistence succeeds.
- Stores malformed messages in `dbo.CliffsKFCWaffles_KafkaInboxErrors`, then commits those poison-message offsets.
- SQL errors stop the worker without committing the failed record. Configure Windows Service recovery to restart it.
- The existing stored procedure's same-day ICN duplicate rule is retained.

## Configure

1. Edit `appsettings.json` with the approved broker, topic, certificate paths and SQL connection.
2. Set the private-key password outside source control, for example:
   `Kafka__SslKeyPassword` as a machine environment variable for the Windows service account.
3. Ensure the Windows service identity can read all certificate files and connect to SQL Server.
4. Run the SQL script in `../SqlScripts/01_Kafka_Integration_Tables.sql`.
5. Build and publish:
   `dotnet restore`
   `dotnet publish -c Release -r win-x64 --self-contained false`

The UDT and stored procedure must already exist exactly as documented in the integration handoff.
