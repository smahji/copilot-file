using System.Text.Json;
using Confluent.Kafka;
using ClaimsKafkaConsumer.Models;
using ClaimsKafkaConsumer.Services;

namespace ClaimsKafkaConsumer;

public sealed class Worker : BackgroundService
{
    private readonly ILogger<Worker> _logger;
    private readonly IConfiguration _configuration;
    private readonly IClaimRepository _repository;

    public Worker(
        ILogger<Worker> logger,
        IConfiguration configuration,
        IClaimRepository repository)
    {
        _logger = logger;
        _configuration = configuration;
        _repository = repository;
    }

    protected override async Task ExecuteAsync(CancellationToken stoppingToken)
    {
        var kafka = _configuration.GetSection("Kafka");
        var topic = Required(kafka["ConsumerTopic"], "Kafka:ConsumerTopic");

        var config = new ConsumerConfig
        {
            BootstrapServers = Required(kafka["BootstrapServers"], "Kafka:BootstrapServers"),
            GroupId = Required(kafka["ConsumerGroup"], "Kafka:ConsumerGroup"),
            ClientId = kafka["ClientId"] ?? "claims-kafka-consumer",
            SecurityProtocol = SecurityProtocol.Ssl,
            SslCaLocation = Required(kafka["SslCaLocation"], "Kafka:SslCaLocation"),
            SslCertificateLocation = Required(kafka["SslCertificateLocation"], "Kafka:SslCertificateLocation"),
            SslKeyLocation = Required(kafka["SslKeyLocation"], "Kafka:SslKeyLocation"),
            SslKeyPassword = kafka["SslKeyPassword"],
            AutoOffsetReset = AutoOffsetReset.Earliest,
            EnableAutoCommit = false,
            EnableAutoOffsetStore = false,
            AllowAutoCreateTopics = false
        };

        using var consumer = new ConsumerBuilder<Ignore, string>(config)
            .SetErrorHandler((_, error) => _logger.LogError("Kafka consumer error: {Reason}", error.Reason))
            .Build();

        consumer.Subscribe(topic);
        _logger.LogInformation("Consumer started. Topic={Topic}, Group={Group}", topic, config.GroupId);

        try
        {
            while (!stoppingToken.IsCancellationRequested)
            {
                ConsumeResult<Ignore, string>? record;
                try
                {
                    record = consumer.Consume(stoppingToken);
                }
                catch (OperationCanceledException) when (stoppingToken.IsCancellationRequested)
                {
                    break;
                }

                if (record?.Message?.Value is null)
                    continue;

                var payload = record.Message.Value;
                InboundClaim? claim;

                try
                {
                    claim = ParseInboundClaim(payload);
                    ValidateClaim(claim);
                }
                catch (Exception ex) when (ex is JsonException or InvalidDataException)
                {
                    // Poison messages are durably recorded before advancing the Kafka offset.
                    await _repository.SaveRejectedMessageAsync(
                        record.Topic, record.Partition.Value, record.Offset.Value,
                        payload, ex.Message, stoppingToken);

                    consumer.Commit(record);
                    _logger.LogError(ex,
                        "Rejected malformed inbound message and stored it for review. Topic={Topic}, Partition={Partition}, Offset={Offset}",
                        record.Topic, record.Partition.Value, record.Offset.Value);
                    continue;
                }

                // If SQL fails, do NOT commit this record and stop the worker.
                // This prevents a later offset commit from skipping the failed message.
                await _repository.InsertInventoryAsync(claim!, stoppingToken);
                consumer.Commit(record);

                _logger.LogInformation(
                    "Kafka offset committed after SQL persistence. ICN={ICN}; Topic={Topic}; Partition={Partition}; Offset={Offset}",
                    claim!.InventoryControlNumber, record.Topic, record.Partition.Value, record.Offset.Value);
            }
        }
        finally
        {
            consumer.Close();
            _logger.LogInformation("Consumer stopped.");
        }
    }

    private static InboundClaim ParseInboundClaim(string json)
    {
        using var document = JsonDocument.Parse(json);
        var root = document.RootElement;

        // Client sends the claim fields inside the "Request" object.
        if (root.TryGetProperty("Request", out var request))
            root = request;

        return new InboundClaim
        {
            InventoryControlNumber = ReadString(root, "inventoryControlNumber"),
            PayLocation = ReadString(root, "payLocation"),
            PayEngine = ReadString(root, "payEngine"),
            OrganizationId = ReadString(root, "organizationID"),
            PolicyNumber = ReadString(root, "policyNumber"),
            ClaimSystemIdentification = ReadString(root, "claimSystemIdentification")
        };
    }

    private static string? ReadString(JsonElement element, string propertyName)
    {
        if (!element.TryGetProperty(propertyName, out var value) ||
            value.ValueKind is JsonValueKind.Null or JsonValueKind.Undefined)
            return null;

        return value.ValueKind == JsonValueKind.String ? value.GetString() : value.ToString();
    }

    private static void ValidateClaim(InboundClaim? claim)
    {
        if (claim is null || string.IsNullOrWhiteSpace(claim.InventoryControlNumber))
            throw new InvalidDataException("Request.inventoryControlNumber is missing or empty.");
    }

    private static string Required(string? value, string settingName) =>
        string.IsNullOrWhiteSpace(value)
            ? throw new InvalidOperationException($"{settingName} is missing.")
            : value;
}
