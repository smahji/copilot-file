namespace ClaimsKafkaConsumer.Models;

public sealed class InboundClaim
{
    public string? InventoryControlNumber { get; init; }
    public string? PayLocation { get; init; }
    public string? PayEngine { get; init; }
    public string? OrganizationId { get; init; }
    public string? PolicyNumber { get; init; }
    public string? ClaimSystemIdentification { get; init; }
}
