using ClaimsKafkaConsumer.Services;

var builder = Host.CreateApplicationBuilder(args);

builder.Services.AddWindowsService(options =>
{
    options.ServiceName = "Claims Kafka Consumer";
});

builder.Services.AddSingleton<IClaimRepository, ClaimRepository>();
builder.Services.AddHostedService<Worker>();

var host = builder.Build();
await host.RunAsync();
