namespace ClaimsKafkaProducer.Models;

public sealed class OutboxMessage
{
    public long OutboxId { get; init; }
    public Guid EventId { get; init; }
    public string? Icn { get; init; }
    public string Payload { get; init; } = string.Empty;
    public Guid LockId { get; init; }
}
