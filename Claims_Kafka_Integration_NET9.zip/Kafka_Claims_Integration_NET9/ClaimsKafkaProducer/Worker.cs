using ClaimsKafkaProducer.Models;
using ClaimsKafkaProducer.Services;

namespace ClaimsKafkaProducer;

public sealed class Worker : BackgroundService
{
    private readonly ILogger<Worker> _logger;
    private readonly OutboxRepository _outbox;
    private readonly IKafkaPublisher _publisher;
    private readonly IConfiguration _configuration;

    public Worker(
        ILogger<Worker> logger,
        OutboxRepository outbox,
        IKafkaPublisher publisher,
        IConfiguration configuration)
    {
        _logger = logger;
        _outbox = outbox;
        _publisher = publisher;
        _configuration = configuration;
    }

    protected override async Task ExecuteAsync(CancellationToken stoppingToken)
    {
        var settings = _configuration.GetSection("ProducerSettings");
        var batchSize = settings.GetValue("BatchSize", 50);
        var pollSeconds = settings.GetValue("PollingIntervalSeconds", 5);
        var maxRetries = settings.GetValue("MaxRetryCount", 10);
        var leaseSeconds = settings.GetValue("LeaseSeconds", 180);

        _logger.LogInformation("Producer started. BatchSize={BatchSize}", batchSize);

        while (!stoppingToken.IsCancellationRequested)
        {
            try
            {
                var batch = await _outbox.ClaimBatchAsync(batchSize, leaseSeconds, stoppingToken);

                foreach (var item in batch)
                {
                    try
                    {
                        var key = string.IsNullOrWhiteSpace(item.Icn)
                            ? item.EventId.ToString("D")
                            : item.Icn.Trim();

                        await _publisher.PublishAsync(key, item.Payload, stoppingToken);
                        await _outbox.MarkAsSentAsync(item, stoppingToken);

                        _logger.LogInformation(
                            "Outbox event published and marked SENT. OutboxId={OutboxId}; EventId={EventId}; ICN={ICN}",
                            item.OutboxId, item.EventId, item.Icn);
                    }
                    catch (OperationCanceledException) when (stoppingToken.IsCancellationRequested)
                    {
                        throw;
                    }
                    catch (Exception ex)
                    {
                        var nextRetry = Math.Min(3600, 15 * (int)Math.Pow(2, Math.Min(6, maxRetries)));
                        _logger.LogError(ex,
                            "Publishing failed. OutboxId={OutboxId}; EventId={EventId}",
                            item.OutboxId, item.EventId);

                        await _outbox.MarkAsFailedAsync(
                            item, ex.Message, maxRetries, nextRetry, stoppingToken);
                    }
                }
            }
            catch (OperationCanceledException) when (stoppingToken.IsCancellationRequested)
            {
                break;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Producer polling cycle failed.");
            }

            await Task.Delay(TimeSpan.FromSeconds(Math.Max(1, pollSeconds)), stoppingToken);
        }

        _logger.LogInformation("Producer stopped.");
    }
}
