using System.Data;
using ClaimsKafkaProducer.Models;
using Microsoft.Data.SqlClient;

namespace ClaimsKafkaProducer.Services;

public sealed class OutboxRepository
{
    private readonly string _connectionString;

    public OutboxRepository(IConfiguration configuration)
    {
        _connectionString = configuration.GetConnectionString("DefaultConnection")
            ?? throw new InvalidOperationException("ConnectionStrings:DefaultConnection is missing.");
    }

    public async Task<IReadOnlyList<OutboxMessage>> ClaimBatchAsync(
        int batchSize, int leaseSeconds, CancellationToken cancellationToken)
    {
        var messages = new List<OutboxMessage>();
        var lockId = Guid.NewGuid();

        const string sql = @"
;WITH NextBatch AS
(
    SELECT TOP (@BatchSize) *
    FROM dbo.CliffWaffles_KafkaOutbox WITH (UPDLOCK, READPAST, ROWLOCK)
    WHERE
        (KafkaStatus = 'PENDING' AND (NextRetryUtc IS NULL OR NextRetryUtc <= SYSUTCDATETIME()))
        OR
        (KafkaStatus = 'PROCESSING' AND LockedUntilUtc < SYSUTCDATETIME())
    ORDER BY OutboxId
)
UPDATE NextBatch
SET KafkaStatus = 'PROCESSING',
    LockId = @LockId,
    LockedUntilUtc = DATEADD(SECOND, @LeaseSeconds, SYSUTCDATETIME())
OUTPUT
    inserted.OutboxId,
    inserted.EventId,
    inserted.ICN,
    inserted.Payload,
    inserted.LockId;";

        await using var connection = new SqlConnection(_connectionString);
        await using var command = new SqlCommand(sql, connection);
        command.Parameters.Add("@BatchSize", SqlDbType.Int).Value = batchSize;
        command.Parameters.Add("@LeaseSeconds", SqlDbType.Int).Value = leaseSeconds;
        command.Parameters.Add("@LockId", SqlDbType.UniqueIdentifier).Value = lockId;

        await connection.OpenAsync(cancellationToken);
        await using var reader = await command.ExecuteReaderAsync(cancellationToken);
        while (await reader.ReadAsync(cancellationToken))
        {
            messages.Add(new OutboxMessage
            {
                OutboxId = reader.GetInt64(0),
                EventId = reader.GetGuid(1),
                Icn = reader.IsDBNull(2) ? null : reader.GetString(2),
                Payload = reader.GetString(3),
                LockId = reader.GetGuid(4)
            });
        }

        return messages;
    }

    public async Task MarkAsSentAsync(OutboxMessage message, CancellationToken cancellationToken)
    {
        const string sql = @"
UPDATE dbo.CliffWaffles_KafkaOutbox
SET KafkaStatus = 'SENT',
    KafkaSent = 1,
    KafkaSentDate = SYSUTCDATETIME(),
    KafkaLastAttemptDate = SYSUTCDATETIME(),
    KafkaError = NULL,
    LockId = NULL,
    LockedUntilUtc = NULL
WHERE OutboxId = @OutboxId
  AND LockId = @LockId
  AND KafkaStatus = 'PROCESSING';";

        await using var connection = new SqlConnection(_connectionString);
        await using var command = new SqlCommand(sql, connection);
        command.Parameters.Add("@OutboxId", SqlDbType.BigInt).Value = message.OutboxId;
        command.Parameters.Add("@LockId", SqlDbType.UniqueIdentifier).Value = message.LockId;
        await connection.OpenAsync(cancellationToken);
        var rows = await command.ExecuteNonQueryAsync(cancellationToken);
        if (rows != 1)
            throw new InvalidOperationException($"Outbox row {message.OutboxId} was not marked SENT; its lease may have changed.");
    }

    public async Task MarkAsFailedAsync(
        OutboxMessage message, string error, int maxRetries, int retryDelaySeconds,
        CancellationToken cancellationToken)
    {
        const string sql = @"
UPDATE dbo.CliffWaffles_KafkaOutbox
SET KafkaRetryCount = KafkaRetryCount + 1,
    KafkaStatus = CASE WHEN KafkaRetryCount + 1 >= @MaxRetries THEN 'FAILED' ELSE 'PENDING' END,
    NextRetryUtc = CASE WHEN KafkaRetryCount + 1 >= @MaxRetries
                        THEN NULL ELSE DATEADD(SECOND, @RetryDelaySeconds, SYSUTCDATETIME()) END,
    KafkaError = @KafkaError,
    KafkaLastAttemptDate = SYSUTCDATETIME(),
    LockId = NULL,
    LockedUntilUtc = NULL
WHERE OutboxId = @OutboxId
  AND LockId = @LockId
  AND KafkaStatus = 'PROCESSING';";

        await using var connection = new SqlConnection(_connectionString);
        await using var command = new SqlCommand(sql, connection);
        command.Parameters.Add("@OutboxId", SqlDbType.BigInt).Value = message.OutboxId;
        command.Parameters.Add("@LockId", SqlDbType.UniqueIdentifier).Value = message.LockId;
        command.Parameters.Add("@MaxRetries", SqlDbType.Int).Value = maxRetries;
        command.Parameters.Add("@RetryDelaySeconds", SqlDbType.Int).Value = retryDelaySeconds;
        command.Parameters.Add("@KafkaError", SqlDbType.NVarChar, 4000).Value =
            error.Length > 4000 ? error[..4000] : error;

        await connection.OpenAsync(cancellationToken);
        await command.ExecuteNonQueryAsync(cancellationToken);
    }
}
