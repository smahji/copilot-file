namespace ClaimsKafkaProducer.Services;

public interface IKafkaPublisher
{
    Task PublishAsync(string key, string payload, CancellationToken cancellationToken);
}
