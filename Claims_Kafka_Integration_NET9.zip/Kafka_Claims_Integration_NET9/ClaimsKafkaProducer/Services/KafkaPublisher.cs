using Confluent.Kafka;

namespace ClaimsKafkaProducer.Services;

public sealed class KafkaPublisher : IKafkaPublisher, IDisposable
{
    private readonly IProducer<string, string> _producer;
    private readonly string _topic;
    private readonly ILogger<KafkaPublisher> _logger;

    public KafkaPublisher(IConfiguration configuration, ILogger<KafkaPublisher> logger)
    {
        _logger = logger;
        var kafka = configuration.GetSection("Kafka");
        _topic = Required(kafka["ProducerTopic"], "Kafka:ProducerTopic");

        var producerConfig = new ProducerConfig
        {
            BootstrapServers = Required(kafka["BootstrapServers"], "Kafka:BootstrapServers"),
            ClientId = kafka["ClientId"] ?? "claims-kafka-producer",
            SecurityProtocol = SecurityProtocol.Ssl,
            SslCaLocation = Required(kafka["SslCaLocation"], "Kafka:SslCaLocation"),
            SslCertificateLocation = Required(kafka["SslCertificateLocation"], "Kafka:SslCertificateLocation"),
            SslKeyLocation = Required(kafka["SslKeyLocation"], "Kafka:SslKeyLocation"),
            SslKeyPassword = kafka["SslKeyPassword"],
            Acks = Acks.All,
            EnableIdempotence = true,
            MessageSendMaxRetries = 5,
            RetryBackoffMs = 1000,
            MessageTimeoutMs = 30000
        };

        _producer = new ProducerBuilder<string, string>(producerConfig)
            .SetErrorHandler((_, error) =>
                _logger.LogError("Kafka producer error: {Reason}", error.Reason))
            .Build();
    }

    public async Task PublishAsync(string key, string payload, CancellationToken cancellationToken)
    {
        // Payload is the exact JSON inserted by the VB.NET automation.
        // Do not deserialize/reserialize it: this preserves optional fields and empty values.
        var result = await _producer.ProduceAsync(
            _topic,
            new Message<string, string> { Key = key, Value = payload },
            cancellationToken);

        _logger.LogInformation(
            "Kafka acknowledged outbound event. Topic={Topic}; Partition={Partition}; Offset={Offset}",
            result.Topic, result.Partition.Value, result.Offset.Value);
    }

    public void Dispose()
    {
        _producer.Flush(TimeSpan.FromSeconds(10));
        _producer.Dispose();
    }

    private static string Required(string? value, string settingName) =>
        string.IsNullOrWhiteSpace(value)
            ? throw new InvalidOperationException($"{settingName} is missing.")
            : value;
}
