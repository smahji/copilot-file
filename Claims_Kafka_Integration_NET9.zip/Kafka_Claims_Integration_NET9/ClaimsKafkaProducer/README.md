# Claims Kafka Producer (.NET 9)

Polls `dbo.CliffWaffles_KafkaOutbox`, publishes each stored JSON payload to the outbound Kafka topic,
waits for Kafka's delivery acknowledgement, then marks the row SENT.

## Outbound JSON structure and empty fields

The Producer intentionally sends the `Payload` column byte-for-byte as a string value. It does not
deserialize the client JSON into a partial C# model and does not serialize database columns. Therefore
keys with `""`, `null`, empty arrays, or empty objects remain exactly as your automation inserted them.

Your VB.NET automation should construct the agreed outer envelope and always include `AutomationResponse`.
Keep all client-contract keys present. Use `""` for unavailable string fields only where the client accepts
an empty string; use `null` for nullable fields only where the client accepts null. The sample files should
be treated as the current shape reference, not proof that every field is mandatory.

## Outbox behavior

- Atomically claims rows using SQL locking and a lease so two producer instances do not normally publish
  the same pending row concurrently.
- Waits for Kafka delivery acknowledgement before marking SENT.
- Retries failures with a delay.
- After `MaxRetryCount`, marks the row FAILED for operational review. No dead-letter topic is configured.
- A crash after Kafka acknowledges a message but before SQL marks it SENT can cause a duplicate on restart.
  Use `EventId` as a stable unique identifier and ask the client to deduplicate it if they support that.

## VB.NET integration requirement

Insert the Outbox row in the SAME SQL transaction as the final `WCRPaymentLog` update. Store the full
client-compatible JSON in `Payload`; do not ask this Producer to reconstruct it later.

Generate `EventId` once (GUID) and retain it across retries. `ICN` is the Kafka message key.

## Configure

1. Set Kafka broker, outbound topic, certificate paths and SQL connection in `appsettings.json`.
2. Set `Kafka__SslKeyPassword` as a machine environment variable for the Windows service account.
3. Run the SQL integration script.
4. Confirm the VB.NET automation inserts one Outbox row for each final status event.
5. Build/publish with `dotnet publish -c Release -r win-x64 --self-contained false`.

Do not commit certificate private keys or passwords to source control.
