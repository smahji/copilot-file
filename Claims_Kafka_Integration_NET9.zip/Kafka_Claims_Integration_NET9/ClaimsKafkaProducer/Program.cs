using ClaimsKafkaProducer.Services;

var builder = Host.CreateApplicationBuilder(args);

builder.Services.AddWindowsService(options =>
{
    options.ServiceName = "Claims Kafka Producer";
});

builder.Services.AddSingleton<OutboxRepository>();
builder.Services.AddSingleton<IKafkaPublisher, KafkaPublisher>();
builder.Services.AddHostedService<Worker>();

var host = builder.Build();
await host.RunAsync();
