Namespace Processing
    ' =====================================================================
    ' ErrorHandler.vb - Centralized error handling
    ' =====================================================================
    Public Class ErrorHandler
        Public Shared Sub HandleUnetError(ex As Exception, logger As Logging.LogManager, step As String)
            Try
                logger.LogError("ErrorHandler", String.Format("Error at step '{0}': {1}", step, ex.Message), ex)
            Catch
                ' Failsafe
            End Try
        End Sub
        
        Public Shared Function GetUserFriendlyMessage(ex As Exception) As String
            If ex.Message.Contains("timeout") Then
                Return "Operation timed out. Please check Unet connection."
            ElseIf ex.Message.Contains("not found") Then
                Return "Claim not found in Unet."
            ElseIf ex.Message.Contains("unauthorized") Then
                Return "Not authorized to access this claim."
            Else
                Return "An error occurred: " & ex.Message
            End If
        End Function
    End Class

    ' =====================================================================
    ' ReversalWorkflow.vb - Defines the steps for claim reversal with void logic
    ' =====================================================================
    Public Class ReversalWorkflow
        Private _unetWrapper As Unet.UnetWrapper
        Private _logger As Logging.LogManager
        Private _icn As String
        Private _unetCredential As Models.DroidCredential
        
        Public Sub New(unetWrapper As Unet.UnetWrapper, logger As Logging.LogManager, icn As String, credential As Models.DroidCredential)
            _unetWrapper = unetWrapper
            _logger = logger
            _icn = icn
            _unetCredential = credential
        End Sub
        
        ''' <summary>
        ''' Executes the complete reversal workflow including void logic
        ''' </summary>
        Public Function Execute() As Models.ProcessingResult
            Dim result As New Models.ProcessingResult With {
                .ICN = _icn,
                .StartTime = DateTime.Now,
                .Status = Configuration.Constants.STATUS_PROCESSING
            }
            
            Try
                ' STEP 1: Verify claim exists
                _logger.LogInfo("ReversalWorkflow", "STEP 1: Verifying claim exists")
                If Not VerifyClaimExists() Then
                    result.Status = Configuration.Constants.STATUS_FAILED
                    result.ErrorMessage = "Claim does not exist or cannot be accessed"
                    result.ReversalStepReached = "ClaimVerification"
                    Return result
                End If
                result.ReversalStepReached = "ClaimVerified"
                
                ' STEP 2: Check if claim is eligible for reversal (void)
                _logger.LogInfo("ReversalWorkflow", "STEP 2: Checking if claim is eligible for reversal")
                If Not CheckClaimEligibilityForReversal() Then
                    result.Status = Configuration.Constants.STATUS_FAILED
                    result.ErrorMessage = "Claim is not eligible for reversal (may be in pend 71/74)"
                    result.ReversalStepReached = "EligibilityCheck"
                    Return result
                End If
                result.ReversalStepReached = "EligibilityChecked"
                
                ' STEP 3: Load claim history and check for void conditions
                _logger.LogInfo("ReversalWorkflow", "STEP 3: Loading claim history and checking void conditions")
                If Not LoadClaimHistory() Then
                    result.Status = Configuration.Constants.STATUS_FAILED
                    result.ErrorMessage = "Failed to load claim history"
                    result.ReversalStepReached = "HistoryLoad"
                    Return result
                End If
                result.ReversalStepReached = "HistoryLoaded"
                
                ' STEP 4: Check for void conditions (Adjuster ID 008273 with paid amount)
                _logger.LogInfo("ReversalWorkflow", "STEP 4: Checking void conditions")
                If Not CheckVoidConditions(result) Then
                    result.Status = Configuration.Constants.STATUS_FAILED
                    result.ErrorMessage = "Claim does not meet void conditions"
                    result.ReversalStepReached = "VoidConditionCheck"
                    Return result
                End If
                result.ReversalStepReached = "VoidConditionsChecked"
                
                ' STEP 5: Perform void operation
                _logger.LogInfo("ReversalWorkflow", "STEP 5: Performing void operation")
                If Not PerformVoidOperation() Then
                    result.Status = Configuration.Constants.STATUS_FAILED
                    result.ErrorMessage = "Failed to perform void operation"
                    result.ReversalStepReached = "VoidOperation"
                    Return result
                End If
                result.ReversalStepReached = "VoidCompleted"
                
                ' SUCCESS
                result.Status = Configuration.Constants.STATUS_SUCCESS
                _logger.LogSuccess("ReversalWorkflow", "Reversal/Void completed successfully for: " & _icn)
                
            Catch ex As Exception
                result.Status = Configuration.Constants.STATUS_FAILED
                result.ErrorMessage = ex.Message
                result.ErrorSource = "ReversalWorkflow.Execute"
                _logger.LogError("ReversalWorkflow", "Exception during workflow execution", ex)
            Finally
                result.EndTime = DateTime.Now
                result.DurationSeconds = CInt((result.EndTime - result.StartTime).TotalSeconds)
            End Try
            
            Return result
        End Function
        
        ''' <summary>
        ''' Verify claim exists on the Unet screen
        ''' Access UnetWrapper properties: _unetWrapper.SessionName, _unetWrapper.UnetID, etc.
        ''' </summary>
        Private Function VerifyClaimExists() As Boolean
            Try
                ' Can now access wrapper properties directly
                _logger.LogInfo("ReversalWorkflow", "Verifying claim with session: " & _unetWrapper.SessionName)
                
                System.Threading.Thread.Sleep(500)
                Dim screenText As String = _unetWrapper.GetText(1, 1, 80, True)
                If InStr(screenText, _icn) > 0 Then
                    _logger.LogSuccess("ReversalWorkflow", "Claim verification successful: " & _icn)
                    _logger.LogInfo("ReversalWorkflow", "Using Unet ID: " & _unetWrapper.UnetID)
                    Return True
                End If
                
                _logger.LogError("ReversalWorkflow", "Claim not found on screen")
                Return False
            Catch ex As Exception
                ErrorHandler.HandleUnetError(ex, _logger, "VerifyClaimExists")
                Return False
            End Try
        End Function
        
        ''' <summary>
        ''' Check if claim is eligible for reversal (not in pend 71/74)
        ''' </summary>
        Private Function CheckClaimEligibilityForReversal() As Boolean
            Try
                Dim screenText As String = _unetWrapper.GetText(24, 1, 80, True)
                
                ' If claim is in pend 71/74, it's not eligible
                If InStr(screenText, "PEND 71") > 0 Or InStr(screenText, "PEND 74") > 0 Then
                    _logger.LogWarning("ReversalWorkflow", "Claim appears to be in pend 71/74 - not eligible")
                    Return False
                End If
                
                ' Check for closed or voided claims
                If InStr(screenText, "CLOSED") > 0 Or InStr(screenText, "VOID") > 0 Then
                    _logger.LogWarning("ReversalWorkflow", "Claim appears to be closed or already voided")
                    Return False
                End If
                
                _logger.LogSuccess("ReversalWorkflow", "Claim eligibility check passed")
                Return True
            Catch ex As Exception
                ErrorHandler.HandleUnetError(ex, _logger, "CheckClaimEligibilityForReversal")
                Return False
            End Try
        End Function
        
        ''' <summary>
        ''' Load claim history (MHI) to access draft details
        ''' This mirrors the code: PullMHI, ReadMHI, GetDraftDetailsInMemory
        ''' </summary>
        Private Function LoadClaimHistory() As Boolean
            Try
                _logger.LogInfo("ReversalWorkflow", "Pulling MHI (Multi-occurrence History)")
                
                ' Navigate to MHI screen
                _unetWrapper.SendClear()
                _unetWrapper.SendClear()
                
                ' This would call your existing PullMHI method from mdlUnet
                ' Placeholder: mdlUnet.PullMHI(_icn)
                
                System.Threading.Thread.Sleep(500)
                
                _logger.LogSuccess("ReversalWorkflow", "Claim history loaded successfully")
                Return True
                
            Catch ex As Exception
                ErrorHandler.HandleUnetError(ex, _logger, "LoadClaimHistory")
                Return False
            End Try
        End Function
        
        ''' <summary>
        ''' Check for void conditions from the LatestVoid code:
        ''' - Adjuster ID must be "008273"
        ''' - Paid amount must be > 0
        ''' </summary>
        Private Function CheckVoidConditions(result As Models.ProcessingResult) As Boolean
            Try
                _logger.LogInfo("ReversalWorkflow", "Checking void conditions (Adjuster 008273 with paid amount > 0)")
                
                ' These would be populated from your claim arrays/objects
                ' Placeholder logic - replace with actual claim data access
                Dim adjusterId As String = "008273"  ' This should come from claim data
                Dim paidAmount As Double = 0  ' This should come from claim data
                
                If adjusterId = "008273" AndAlso paidAmount > 0 Then
                    _logger.LogSuccess("ReversalWorkflow", "Void conditions met - Adjuster: " & adjusterId & ", Amount: " & paidAmount)
                    Return True
                Else
                    _logger.LogWarning("ReversalWorkflow", "Void conditions NOT met - Adjuster: " & adjusterId & ", Amount: " & paidAmount)
                    Return False
                End If
                
            Catch ex As Exception
                ErrorHandler.HandleUnetError(ex, _logger, "CheckVoidConditions")
                Return False
            End Try
        End Function
        
        ''' <summary>
        ''' Perform the actual void operation (PerformVoid_For74AAProcess equivalent)
        ''' </summary>
        Private Function PerformVoidOperation() As Boolean
            Try
                _logger.LogInfo("ReversalWorkflow", "Initiating void operation")
                
                ' Navigate to void screen
                _unetWrapper.SendClear()
                _unetWrapper.SendClear()
                
                ' Send control line to initiate void
                ' Replace with actual void control line
                _unetWrapper.SendKeys("MEI,I" & _icn & ",100")
                _unetWrapper.SendEnter()
                
                System.Threading.Thread.Sleep(500)
                
                ' Check if void was successful
                Dim screenText As String = _unetWrapper.GetText(24, 1, 80, True)
                
                If InStr(screenText, "ACCEPTED") > 0 Or InStr(screenText, "COMPLETE") > 0 Or InStr(screenText, "VOIDED") > 0 Then
                    _logger.LogSuccess("ReversalWorkflow", "Void operation successful")
                    Return True
                ElseIf InStr(screenText, "DENIED") > 0 Or InStr(screenText, "ERROR") > 0 Then
                    _logger.LogError("ReversalWorkflow", "Void operation denied/errored: " & screenText)
                    Return False
                Else
                    _logger.LogWarning("ReversalWorkflow", "Void operation status unclear - assuming success")
                    Return True
                End If
                
            Catch ex As Exception
                ErrorHandler.HandleUnetError(ex, _logger, "PerformVoidOperation")
                Return False
            End Try
        End Function
    End Class

    ' =====================================================================
    ' ClaimProcessor.vb - Main orchestration with credential caching
    ' =====================================================================
    Public Class ClaimProcessor
        Private _dbHelper As Database.DatabaseHelper
        Private _sessionName As String
        Private _unetSession As Unet.UnetSession
        Private _processingResults As New List(Of Models.ProcessingResult)
        Private _shouldStop As Boolean = False
        Private _metrics As Models.DashboardMetrics
        
        ' CREDENTIALS CACHE - Fetched once, reused for all claims
        Private _cachedCredentials As Dictionary(Of String, Models.DroidCredential)
        
        Public Event ProcessingStarted(message As String)
        Public Event ProcessingProgress(result As Models.ProcessingResult)
        Public Event ProcessingComplete(totalProcessed As Integer, successful As Integer, failed As Integer)
        Public Event ErrorOccurred(message As String)
        
        Public Sub New(sessionName As String)
            _sessionName = sessionName.ToUpper()
            _dbHelper = New Database.DatabaseHelper()
            _metrics = New Models.DashboardMetrics()
            _cachedCredentials = New Dictionary(Of String, Models.DroidCredential)
        End Sub
        
        ''' <summary>
        ''' Starts batch processing of all ICNs with priority_flag = 2
        ''' NOW CACHES CREDENTIALS ONCE AT THE START
        ''' </summary>
        Public Sub StartBatchProcessing()
            Try
                RaiseEvent ProcessingStarted("Starting batch processing with session: " & _sessionName)
                
                ' Initialize configuration
                Dim config As Configuration.ConfigManager = Configuration.ConfigManager.GetInstance()
                config.LoadSettings()
                config.EnsureLogDirectoriesExist()
                
                ' ===== NEW: FETCH AND CACHE ALL CREDENTIALS ONCE =====
                RaiseEvent ProcessingStarted("Fetching credentials (cached for all claims)...")
                Try
                    _cachedCredentials = _dbHelper.FetchAllCredentials()
                    If _cachedCredentials.Count = 0 Then
                        RaiseEvent ErrorOccurred("No credentials found in DroidCred table")
                        Return
                    End If
                    RaiseEvent ProcessingStarted("Credentials cached successfully: " & _cachedCredentials.Count & " localities")
                Catch ex As Exception
                    RaiseEvent ErrorOccurred("Failed to fetch credentials: " & ex.Message)
                    Return
                End Try
                ' ===== END: CREDENTIAL CACHING =====
                
                ' Fetch all ICNs ready for processing
                Dim claimsToProcess As List(Of Models.ClaimRecord) = _dbHelper.FetchICNsByFlag(Configuration.Constants.FLAG_READY_TO_PROCESS)
                
                If claimsToProcess.Count = 0 Then
                    RaiseEvent ProcessingStarted("No claims ready for processing")
                    Return
                End If
                
                _metrics.TotalClaims = claimsToProcess.Count
                
                ' Process each claim sequentially
                For Each claim In claimsToProcess
                    If _shouldStop Then Exit For
                    
                    ' PASS CACHED CREDENTIALS TO PROCESS METHOD
                    ProcessSingleClaim(claim, config, _cachedCredentials)
                    
                    ' Update metrics
                    Dim successful As Integer = _processingResults.Where(Function(r) r.Status = Configuration.Constants.STATUS_SUCCESS).Count()
                    Dim failed As Integer = _processingResults.Where(Function(r) r.Status = Configuration.Constants.STATUS_FAILED).Count()
                    _metrics.UpdateMetrics(claimsToProcess.Count, successful, failed)
                Next
                
                RaiseEvent ProcessingComplete(_processingResults.Count, 
                                             _processingResults.Where(Function(r) r.Status = Configuration.Constants.STATUS_SUCCESS).Count(),
                                             _processingResults.Where(Function(r) r.Status = Configuration.Constants.STATUS_FAILED).Count())
                
            Catch ex As Exception
                RaiseEvent ErrorOccurred("Error during batch processing: " & ex.Message)
            End Try
        End Sub
        
        ''' <summary>
        ''' Processes a single claim through the reversal workflow
        ''' NOW RECEIVES CACHED CREDENTIALS INSTEAD OF QUERYING DB
        ''' </summary>
        Private Sub ProcessSingleClaim(claim As Models.ClaimRecord, config As Configuration.ConfigManager, cachedCredentials As Dictionary(Of String, Models.DroidCredential))
            Dim logger As Logging.LogManager = Nothing
            Dim unetWrapper As Unet.UnetWrapper = Nothing
            
            Try
                ' Step 1: Update claim status to "Processing" (Flag 9)
                _dbHelper.UpdatePriorityFlag(claim.ICN, Configuration.Constants.FLAG_CURRENTLY_PROCESSING)
                
                ' Step 2: Initialize logger for this ICN
                logger = New Logging.LogManager(claim.ICN, claim.Locality)
                logger.LogInfo("ClaimProcessor", "Started processing ICN: " & claim.ICN)
                
                ' Step 3: Get credential from CACHE (no DB call needed)
                Dim credential As Models.DroidCredential = _dbHelper.GetCredentialFromCache(cachedCredentials, claim.Locality)
                If credential Is Nothing Then
                    Throw New Exception("No cached credential found for locality: " & claim.Locality)
                End If
                logger.LogInfo("ClaimProcessor", "Using cached credentials for locality: " & claim.Locality)
                
                ' Step 4: Initialize Unet wrapper
                unetWrapper = New Unet.UnetWrapper(_sessionName, credential.ID, credential.Pass, logger)
                If Not unetWrapper.InitializeEmulator() Then
                    Throw New Exception("Failed to initialize Unet emulator")
                End If
                
                ' Step 5: Execute reversal workflow with credential and wrapper
                ' NOW PASSES CREDENTIAL TO WORKFLOW
                Dim workflow As New ReversalWorkflow(unetWrapper, logger, claim.ICN, credential)
                Dim result As Models.ProcessingResult = workflow.Execute()
                
                ' Set additional result properties
                result.Engine = claim.Engine
                result.Office = claim.Office
                result.PostFlagValue = If(result.Status = Configuration.Constants.STATUS_SUCCESS, Configuration.Constants.FLAG_SUCCESS, Configuration.Constants.FLAG_FAILURE)
                
                ' Step 6: Update priority flag based on result
                _dbHelper.UpdatePriorityFlag(claim.ICN, result.PostFlagValue)
                
                ' Step 7: Log result to database and file
                logger.LogProcessingResult(result)
                
                ' Step 8: Add to results list
                _processingResults.Add(result)
                
                ' Step 9: Notify UI
                RaiseEvent ProcessingProgress(result)
                
                logger.LogSuccess("ClaimProcessor", "Processing completed for ICN: " & claim.ICN & " - Status: " & result.Status)
                
            Catch ex As Exception
                If logger IsNot Nothing Then
                    logger.LogError("ClaimProcessor", "Error processing claim: " & claim.ICN, ex)
                End If
                
                ' Mark as failed
                Try
                    _dbHelper.UpdatePriorityFlag(claim.ICN, Configuration.Constants.FLAG_FAILURE)
                Catch
                End Try
                
                ' Add failed result
                _processingResults.Add(New Models.ProcessingResult With {
                    .ICN = claim.ICN,
                    .Status = Configuration.Constants.STATUS_FAILED,
                    .ErrorMessage = ex.Message,
                    .ErrorSource = "ClaimProcessor.ProcessSingleClaim",
                    .Engine = claim.Engine,
                    .Office = claim.Office,
                    .PostFlagValue = Configuration.Constants.FLAG_FAILURE,
                    .StartTime = DateTime.Now,
                    .EndTime = DateTime.Now
                })
                
                RaiseEvent ProcessingProgress(_processingResults.Last())
                
            Finally
                If unetWrapper IsNot Nothing Then
                    unetWrapper.CloseSession()
                End If
            End Try
        End Sub
        
        ''' <summary>
        ''' Stops the processing batch
        ''' </summary>
        Public Sub StopProcessing()
            _shouldStop = True
        End Sub
        
        Public ReadOnly Property Results As List(Of Models.ProcessingResult)
            Get
                Return _processingResults
            End Get
        End Property
        
        Public ReadOnly Property Metrics As Models.DashboardMetrics
            Get
                Return _metrics
            End Get
        End Property

    End Class

End Namespace
