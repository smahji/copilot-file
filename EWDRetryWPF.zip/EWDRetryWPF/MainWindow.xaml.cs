using System.Windows;

namespace EWDRetryWPF
{
    public partial class MainWindow : Window
    {
        public MainWindow() => InitializeComponent();
    }
}
