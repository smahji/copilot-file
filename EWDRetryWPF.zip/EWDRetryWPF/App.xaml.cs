using System.Windows;

namespace EWDRetryWPF
{
    public partial class App : Application { }
}
