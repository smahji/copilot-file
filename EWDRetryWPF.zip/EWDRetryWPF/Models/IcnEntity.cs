namespace EWDRetryWPF.Models
{
    public class IcnEntity
    {
        public string ICN      { get; set; }
        public string Engine   { get; set; }
        public string Office   { get; set; }
        public string Locality { get; set; }
        public string Msid     { get; set; }
        public string OrgId    { get; set; }
        public string Priority_flag { get; set; }
    }
}
