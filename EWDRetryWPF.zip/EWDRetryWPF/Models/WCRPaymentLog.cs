using System;

namespace EWDRetryWPF.Models
{
    public partial class WCRPaymentLog
    {
        public long      Id                    { get; set; }
        public string    ICN                   { get; set; }
        public string    Engine                { get; set; }
        public string    Office                { get; set; }
        public int?      Processable           { get; set; }
        public int?      IsCA                  { get; set; }
        public int?      IsEW                  { get; set; }
        public int?      isGR                  { get; set; }
        public int?      isER                  { get; set; }
        public int?      isUP                  { get; set; }
        public int?      isLP                  { get; set; }
        public int?      isUnderPayment        { get; set; }
        public int?      isZeroPayment         { get; set; }
        public string    HistoryICNList        { get; set; }
        public int?      isProcessed           { get; set; }
        public DateTime? DateResearch          { get; set; }
        public DateTime? DateProcess           { get; set; }
        public string    ResearchComment       { get; set; }
        public string    PaymentComment        { get; set; }
        public string    NTID                  { get; set; }
        public string    SubrogationRemarkCode { get; set; }
        public int?      isInvestigateCob      { get; set; }
        public int?      IsRCCA                { get; set; }
        public string    AmountToBeAdjusted    { get; set; }
        public int?      is30LineReqd          { get; set; }
        public int?      is30LineToBeUsed      { get; set; }
        public int?      isPickedUp            { get; set; }
        public string    Policy                { get; set; }
        public string    Result                { get; set; }
        public string    SuffixCount           { get; set; }
        public string    Locality              { get; set; }
        public string    UBStatus              { get; set; }
        public string    PickStatus            { get; set; }
        public int?      IsOverpayment         { get; set; }
        public int?      IsOON                 { get; set; }
        public int?      IsOverride01          { get; set; }
        public int?      IsPgpolicy            { get; set; }
        public string    Isbilltype            { get; set; }
    }
}
