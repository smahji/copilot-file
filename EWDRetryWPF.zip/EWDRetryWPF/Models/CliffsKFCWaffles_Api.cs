using System;

namespace EWDRetryWPF.Models
{
    public partial class CliffsKFCWaffles_Api
    {
        public long      Id              { get; set; }
        public string    ICN             { get; set; }
        public string    Payloc          { get; set; }
        public string    Engine          { get; set; }
        public string    OrgID           { get; set; }
        public string    Policy          { get; set; }
        public string    Locality        { get; set; }
        public int?      CD_Claim_Age    { get; set; }
        public int?      Claim_Specialty { get; set; }
        public int?      Priority_Flag   { get; set; }
        public string    Status          { get; set; }
        public DateTime? Timestamp       { get; set; }
        public string    MSID            { get; set; }
        public string    Claim_Notes     { get; set; }
        public DateTime? Upload_date     { get; set; }
        public string    ORS             { get; set; }
        public string    Filter_Droid    { get; set; }
        public string    BP_Droid        { get; set; }
        public string    ZeroPaid        { get; set; }
        public string    Region          { get; set; }
        public DateTime? InapTime        { get; set; }
        public string    InapCheckOut    { get; set; }
    }
}
