using System;

namespace EWDRetryWPF.Models
{
    public partial class CliffsKFCWaffle
    {
        public long      ID                  { get; set; }
        public string    OrgID               { get; set; }
        public string    Pay_Eng             { get; set; }
        public string    Pay_Off             { get; set; }
        public string    Policy              { get; set; }
        public string    ICN                 { get; set; }
        public string    Locality            { get; set; }
        public int?      CD_Claim_Age        { get; set; }
        public int?      CD_In_Status        { get; set; }
        public int?      Claim_Specialty     { get; set; }
        public int?      Priority_Flag       { get; set; }
        public string    Status              { get; set; }
        public DateTime? Timestamp           { get; set; }
        public string    MSID               { get; set; }
        public string    Claim_Notes        { get; set; }
        public DateTime? Upload_date        { get; set; }
        public string    ORS                { get; set; }
        public string    Filter_Droid       { get; set; }
        public string    BP_Droid           { get; set; }
        public string    ZeroPaid           { get; set; }
        public string    Suspend_Reason     { get; set; }
        public DateTime? Original_Upload    { get; set; }
        public string    Original_Work_Queue { get; set; }
        public string    New_Work_Queue     { get; set; }
        public string    Routing_Agent      { get; set; }
        public string    Support            { get; set; }
        public int?      InapRuns           { get; set; }
        public DateTime? InapTime           { get; set; }
        public string    BP_PC              { get; set; }
        public string    InapCheckOut       { get; set; }
        public string    BP_CheckOut        { get; set; }
    }
}
