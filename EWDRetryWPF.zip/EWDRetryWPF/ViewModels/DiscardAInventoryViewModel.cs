using System;
using System.Collections.ObjectModel;
using System.Threading;
using System.Windows;
using EWDRetryWPF.Helpers;
using EWDRetryWPF.Models;
using EWDRetryWPF.Services;

namespace EWDRetryWPF.ViewModels
{
    public class DiscardAInventoryViewModel : BaseViewModel
    {
        private readonly DataService _data = new DataService();
        private readonly ApiService  _api  = new ApiService();

        private CancellationTokenSource _cts;

        // ─── Observable properties ────────────────────────────────────────────────

        private string _statusText = "Ready";
        public  string  StatusText { get => _statusText; set => SetField(ref _statusText, value); }

        private string _icnsLeftText = "—";
        public  string  IcnsLeftText { get => _icnsLeftText; set => SetField(ref _icnsLeftText, value); }

        private string _successCount = "0";
        public  string  SuccessCount { get => _successCount; set => SetField(ref _successCount, value); }

        private string _failCount = "0";
        public  string  FailCount { get => _failCount; set => SetField(ref _failCount, value); }

        private bool _isRunning;
        public  bool  IsRunning
        {
            get => _isRunning;
            set { SetField(ref _isRunning, value); OnPropertyChanged(nameof(IsNotRunning)); }
        }
        public bool IsNotRunning => !_isRunning;

        private DateTime _fromDate = new DateTime(2024, 6, 15);
        public  DateTime  FromDate { get => _fromDate; set => SetField(ref _fromDate, value); }

        private ObservableCollection<IcnEntity> _currentIcns = new ObservableCollection<IcnEntity>();
        public  ObservableCollection<IcnEntity>  CurrentIcns
        {
            get => _currentIcns;
            set => SetField(ref _currentIcns, value);
        }

        // ─── Commands ─────────────────────────────────────────────────────────────

        public RelayCommand StartCommand { get; }
        public RelayCommand StopCommand  { get; }

        public DiscardAInventoryViewModel()
        {
            StartCommand = new RelayCommand(_ => Start(), _ => !IsRunning);
            StopCommand  = new RelayCommand(_ => Stop(),  _ =>  IsRunning);
        }

        // ─── Start / Stop ─────────────────────────────────────────────────────────

        private void Start()
        {
            _cts      = new CancellationTokenSource();
            IsRunning = true;
            StatusText    = "Starting…";
            IcnsLeftText  = "—";
            ResetCounters();

            var token = _cts.Token;
            ThreadPool.QueueUserWorkItem(_ => RunLoop(token));
        }

        private void Stop()
        {
            _cts?.Cancel();
            IsRunning  = false;
            StatusText = "Stopped by user";
        }

        // ─── Processing loop (mirrors DiscardAEngineinventory) ───────────────────

        private void RunLoop(CancellationToken token)
        {
            int success = 0, fail = 0;
            try
            {
                while (!token.IsCancellationRequested)
                {
                    var batch = _data.GetDiscardAEngineBatch(FromDate);
                    int total = _data.GetDiscardAEnginePendingCount(FromDate);

                    SetUi(() => IcnsLeftText = total.ToString());

                    if (batch.Count == 0)
                    {
                        SetUi(() =>
                        {
                            StatusText   = "A Engine Discard Finished ✓";
                            IcnsLeftText = "0";
                            IsRunning    = false;
                        });
                        break;
                    }

                    SetUi(() => StatusText = "A engine discard running…");

                    foreach (var icn in batch)
                    {
                        if (token.IsCancellationRequested) break;
                        if (string.IsNullOrEmpty(icn)) continue;

                        var icnObj = new IcnEntity { ICN = icn };
                        SetUi(() =>
                        {
                            CurrentIcns.Clear();
                            CurrentIcns.Add(icnObj);
                        });

                        // A-engine always uses Optum endpoint with priority flag 4
                        bool ok = _api.CallOptumAPIforAEngine(icn, "4");
                        _data.UpdateApiStatus(icn, ok ? 2 : 3);

                        if (ok) success++; else fail++;
                        int s = success, f = fail;
                        SetUi(() => { SuccessCount = s.ToString(); FailCount = f.ToString(); });
                    }
                }
            }
            catch (Exception ex)
            {
                SetUi(() =>
                {
                    StatusText = $"Error: {ex.Message}";
                    IsRunning  = false;
                });
            }
            finally
            {
                SetUi(() => IsRunning = false);
            }
        }

        // ─── Helpers ─────────────────────────────────────────────────────────────

        private void SetUi(Action action) =>
            Application.Current?.Dispatcher.Invoke(action);

        private void ResetCounters()
        {
            SuccessCount = "0";
            FailCount    = "0";
            CurrentIcns.Clear();
        }
    }
}
