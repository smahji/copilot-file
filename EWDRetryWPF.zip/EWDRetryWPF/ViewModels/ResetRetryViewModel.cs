using System;
using System.Windows;
using EWDRetryWPF.Helpers;
using EWDRetryWPF.Services;

namespace EWDRetryWPF.ViewModels
{
    public class ResetRetryViewModel : BaseViewModel
    {
        private readonly DataService _data = new DataService();

        private string _failCount = "—";
        public  string  FailCount { get => _failCount; set => SetField(ref _failCount, value); }

        private string _statusText = "Ready";
        public  string  StatusText { get => _statusText; set => SetField(ref _statusText, value); }

        private bool _isBusy;
        public  bool  IsBusy { get => _isBusy; set { SetField(ref _isBusy, value); OnPropertyChanged(nameof(IsIdle)); } }
        public  bool  IsIdle => !_isBusy;

        public RelayCommand RefreshCountCommand { get; }
        public RelayCommand ResetCommand        { get; }

        public ResetRetryViewModel()
        {
            RefreshCountCommand = new RelayCommand(_ => RefreshCount(), _ => IsIdle);
            ResetCommand        = new RelayCommand(_ => Reset(),        _ => IsIdle);
        }

        private void RefreshCount()
        {
            IsBusy = true;
            StatusText = "Fetching count…";
            try
            {
                int count = _data.GetRetryFailCount();
                FailCount  = count.ToString();
                StatusText = "Count refreshed";
            }
            catch (Exception ex)
            {
                StatusText = $"Error: {ex.Message}";
            }
            finally
            {
                IsBusy = false;
            }
        }

        private void Reset()
        {
            var confirm = MessageBox.Show(
                $"This will reset {FailCount} failed ICNs (ORS=3 → ORS=0) for the last 45 days.\n\nProceed?",
                "Confirm Reset", MessageBoxButton.YesNo, MessageBoxImage.Warning);

            if (confirm != MessageBoxResult.Yes) return;

            IsBusy = true;
            StatusText = "Resetting…";
            try
            {
                int rows = _data.ResetRetryFails();
                FailCount  = "0";
                StatusText = $"Reset complete — {rows} rows updated";
            }
            catch (Exception ex)
            {
                StatusText = $"Error: {ex.Message}";
            }
            finally
            {
                IsBusy = false;
            }
        }
    }
}
