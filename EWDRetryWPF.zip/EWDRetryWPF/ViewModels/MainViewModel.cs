namespace EWDRetryWPF.ViewModels
{
    public class MainViewModel : BaseViewModel
    {
        public RetryViewModel           RetryVM           { get; } = new RetryViewModel();
        public ResetRetryViewModel      ResetRetryVM      { get; } = new ResetRetryViewModel();
        public DiscardAInventoryViewModel DiscardAVM      { get; } = new DiscardAInventoryViewModel();
    }
}
