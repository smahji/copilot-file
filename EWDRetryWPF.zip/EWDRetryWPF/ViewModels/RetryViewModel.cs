using System;
using System.Collections.ObjectModel;
using System.Threading;
using System.Windows;
using EWDRetryWPF.Helpers;
using EWDRetryWPF.Models;
using EWDRetryWPF.Services;

namespace EWDRetryWPF.ViewModels
{
    public class RetryViewModel : BaseViewModel
    {
        private readonly DataService _data = new DataService();
        private readonly ApiService  _api  = new ApiService();

        private CancellationTokenSource _cts;

        // ─── Observable properties ────────────────────────────────────────────────

        private string _statusText = "Ready";
        public  string  StatusText { get => _statusText; set => SetField(ref _statusText, value); }

        private string _icnsLeftText = "—";
        public  string  IcnsLeftText { get => _icnsLeftText; set => SetField(ref _icnsLeftText, value); }

        private string _successCount = "0";
        public  string  SuccessCount { get => _successCount; set => SetField(ref _successCount, value); }

        private string _failCount = "0";
        public  string  FailCount { get => _failCount; set => SetField(ref _failCount, value); }

        private bool _isRunning;
        public  bool  IsRunning
        {
            get => _isRunning;
            set { SetField(ref _isRunning, value); OnPropertyChanged(nameof(IsNotRunning)); }
        }
        public bool IsNotRunning => !_isRunning;

        private DateTime _fromDate = new DateTime(2024, 6, 15);
        public  DateTime  FromDate { get => _fromDate; set => SetField(ref _fromDate, value); }

        // Current ICN being processed — shown in the data grid
        private ObservableCollection<IcnEntity> _currentIcn = new ObservableCollection<IcnEntity>();
        public  ObservableCollection<IcnEntity>  CurrentIcn
        {
            get => _currentIcn;
            set => SetField(ref _currentIcn, value);
        }

        // ─── Commands ─────────────────────────────────────────────────────────────

        public RelayCommand StartCommand { get; }
        public RelayCommand StopCommand  { get; }

        public RetryViewModel()
        {
            StartCommand = new RelayCommand(_ => Start(), _ => !IsRunning);
            StopCommand  = new RelayCommand(_ => Stop(),  _ =>  IsRunning);
        }

        // ─── Start / Stop ─────────────────────────────────────────────────────────

        private void Start()
        {
            _cts      = new CancellationTokenSource();
            IsRunning = true;
            StatusText    = "Starting…";
            IcnsLeftText  = "—";
            ResetCounters();

            var token = _cts.Token;
            ThreadPool.QueueUserWorkItem(_ => RunLoop(token));
        }

        private void Stop()
        {
            _cts?.Cancel();
            IsRunning  = false;
            StatusText = "Stopped by user";
        }

        // ─── Processing loop (mirrors RetryInventorytoEWD3) ──────────────────────

        private void RunLoop(CancellationToken token)
        {
            int success = 0, fail = 0;
            try
            {
                while (!token.IsCancellationRequested)
                {
                    var batch = _data.GetRetryBatch(FromDate);
                    int total = _data.GetRetryPendingCount(FromDate);

                    SetUi(() => IcnsLeftText = total.ToString());

                    if (batch.Count == 0)
                    {
                        SetUi(() =>
                        {
                            StatusText   = "Retry complete ✓";
                            IcnsLeftText = "0";
                            IsRunning    = false;
                        });
                        break;
                    }

                    SetUi(() => StatusText = "Retry running…");

                    foreach (var row in batch)
                    {
                        if (token.IsCancellationRequested) break;
                        if (string.IsNullOrEmpty(row.ICN)) continue;

                        var icnObj = new IcnEntity
                        {
                            ICN      = row.ICN,
                            Engine   = row.Engine?.Trim(),
                            Office   = row.Office?.Trim(),
                            OrgId    = row.OrgID?.Trim(),
                            Locality = row.Locality
                        };

                        // Update live display
                        SetUi(() =>
                        {
                            CurrentIcn.Clear();
                            CurrentIcn.Add(icnObj);
                        });

                        bool ok;
                        if (row.Priority_Flag == 2)
                        {
                            // Priority 2 → Optum REST API
                            ok = _api.CallOptumAPI(row.ICN, "2");
                        }
                        else
                        {
                            // Priority 4 (or null) → OGA JSON API
                            ok = _api.CallOgaAPI("Hello", "6", "holmes_aut_u1", icnObj);
                        }

                        _data.UpdateApiStatus(row.ICN, ok ? 2 : 3);

                        if (ok) success++; else fail++;
                        int s = success, f = fail;
                        SetUi(() => { SuccessCount = s.ToString(); FailCount = f.ToString(); });
                    }
                }
            }
            catch (Exception ex)
            {
                SetUi(() =>
                {
                    StatusText = $"Error: {ex.Message}";
                    IsRunning  = false;
                });
            }
            finally
            {
                SetUi(() => IsRunning = false);
            }
        }

        // ─── Helpers ─────────────────────────────────────────────────────────────

        private void SetUi(Action action) =>
            Application.Current?.Dispatcher.Invoke(action);

        private void ResetCounters()
        {
            SuccessCount = "0";
            FailCount    = "0";
            CurrentIcn.Clear();
        }
    }
}
