using System;
using System.IO;

namespace EWDRetryWPF.Services
{
    /// <summary>
    /// Mirrors the LogData / LogDataForAengine static methods from the original dataOperation class.
    /// Writes timestamped log lines to UNC share paths.
    /// </summary>
    public static class LogService
    {
        // Base UNC path for general retry logs
        private const string BaseLogPath       = @"\\nas01042pn\data\WCC_Droid_Drive\RetryLog";
        // Sub-folder for A-engine specific logs
        private const string AEngineSubFolder  = "A Engine";

        /// <summary>General retry log.</summary>
        public static void Log(string message, string dateKey)
            => WriteLog(message, Path.Combine(BaseLogPath, DateTime.Today.ToString("MMM"),
                                              DateTime.Today.ToString("ddMMyy")), dateKey);

        /// <summary>A-engine retry log.</summary>
        public static void LogAEngine(string message, string dateKey)
            => WriteLog(message, Path.Combine(BaseLogPath, AEngineSubFolder,
                                              DateTime.Today.ToString("MMM"),
                                              DateTime.Today.ToString("ddMMyy")), dateKey);

        private static void WriteLog(string message, string folder, string fileKey)
        {
            try
            {
                if (!Directory.Exists(folder))
                    Directory.CreateDirectory(folder);

                string filePath = Path.Combine(folder, fileKey + ".txt");

                using (var writer = new StreamWriter(filePath, append: true))
                    writer.WriteLine(message);
            }
            catch (Exception ex)
            {
                // Swallow log failures — don't crash the main processing loop
                System.Diagnostics.Debug.WriteLine($"[LogService] Failed to write log: {ex.Message}");
            }
        }

        public static string BuildLine(string icn, string statusCode, string content)
            => $"{DateTime.Now}::{icn}== StatusCode {statusCode} -{content}";
    }
}
