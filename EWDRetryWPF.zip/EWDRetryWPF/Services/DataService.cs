using System;
using System.Collections.Generic;
using System.Linq;
using EWDRetryWPF.Data;
using EWDRetryWPF.Models;

namespace EWDRetryWPF.Services
{
    /// <summary>
    /// All database read/write operations extracted from the original dataOperation class.
    /// Uses two EF DbContexts:
    ///   - NIA2019202Entities  → API database (CliffsKFCWaffles_Api, WCRPaymentLog_Api)
    ///   - EIAutomationTeam02Entities → source database (CliffsKFCWaffle, WCRPaymentLog)
    /// </summary>
    public class DataService
    {
        // ─── Retry Tab (RetryInventorytoEWD3) ────────────────────────────────────

        /// <summary>
        /// Fetches up to 100 ICNs with ORS == "0" from the API DB joined to WCRPaymentLog_Api.
        /// Ordered by Upload_date descending.
        /// </summary>
        public List<RetryIcnRow> GetRetryBatch(DateTime fromDate)
        {
            using (var ctx = new NIA2019202Entities())
            {
                var rows = (from kfc in ctx.CliffsKFCWaffles_Api
                            join wcr in ctx.WCRPaymentLog_Api on kfc.ICN equals wcr.ICN
                            where kfc.Upload_date < DateTime.Now
                               && kfc.Upload_date >= fromDate
                               && kfc.ORS == "0"
                            orderby kfc.Upload_date descending
                            select new RetryIcnRow
                            {
                                ICN          = kfc.ICN,
                                Engine       = wcr.Engine,
                                Office       = wcr.Office,
                                OrgID        = kfc.OrgID,
                                Locality     = wcr.Locality,
                                Priority_Flag = kfc.Priority_Flag
                            }).Take(100).ToList();
                return rows;
            }
        }

        /// <summary>Total pending ICNs (ORS == "0") from the given date.</summary>
        public int GetRetryPendingCount(DateTime fromDate)
        {
            using (var ctx = new NIA2019202Entities())
            {
                return (from kfc in ctx.CliffsKFCWaffles_Api
                        join wcr in ctx.WCRPaymentLog_Api on kfc.ICN equals wcr.ICN
                        where kfc.Upload_date < DateTime.Now
                           && kfc.Upload_date >= fromDate
                           && kfc.ORS == "0"
                        select kfc.ICN).Count();
            }
        }

        // ─── Discard A-Engine Tab (DiscardAEngineinventory) ──────────────────────

        /// <summary>
        /// Fetches up to 100 A-engine ICNs where ORS is null/"0" and ZeroPaid is null.
        /// </summary>
        public List<string> GetDiscardAEngineBatch(DateTime fromDate)
        {
            using (var ctx = new NIA2019202Entities())
            {
                return (from kfc in ctx.CliffsKFCWaffles_Api
                        where kfc.Engine == "A"
                           && kfc.Upload_date >= fromDate
                           && kfc.ZeroPaid == null
                           && (kfc.ORS == null || kfc.ORS == "0")
                        select kfc.ICN).Take(100).ToList();
            }
        }

        /// <summary>Total pending A-engine ICNs.</summary>
        public int GetDiscardAEnginePendingCount(DateTime fromDate)
        {
            using (var ctx = new NIA2019202Entities())
            {
                return (from kfc in ctx.CliffsKFCWaffles_Api
                        where kfc.Engine == "A"
                           && kfc.Upload_date >= fromDate
                           && kfc.ZeroPaid == null
                           && (kfc.ORS == null || kfc.ORS == "0")
                        select kfc.ICN).Count();
            }
        }

        // ─── Reset Retry Fails Tab ────────────────────────────────────────────────

        /// <summary>Count of ICNs with ORS == "3" in last 45 days.</summary>
        public int GetRetryFailCount()
        {
            using (var ctx = new NIA2019202Entities())
            {
                var cutoff = DateTime.Now.AddDays(-45);
                return ctx.CliffsKFCWaffles_Api
                          .Count(k => k.Upload_date >= cutoff && k.ORS == "3");
            }
        }

        /// <summary>Resets ORS from "3" → "0" for ICNs within last 45 days.</summary>
        public int ResetRetryFails()
        {
            using (var ctx = new NIA2019202Entities())
            {
                var cutoff = DateTime.Now.AddDays(-45);
                string query = $"Update CliffsKFCWaffles_Api Set ORS='0' " +
                               $"WHERE Upload_date >= '{cutoff:yyyy-MM-dd}' AND ORS='3'";
                return ctx.Database.ExecuteSqlCommand(query);
            }
        }

        // ─── ORS Status Update ────────────────────────────────────────────────────

        /// <summary>Updates ORS column: 2 = success, 3 = fail.</summary>
        public void UpdateApiStatus(string icn, int status)
        {
            using (var ctx = new NIA2019202Entities())
            {
                string query = $"Update CliffsKFCWaffles_Api Set ORS='{status}' WHERE ICN='{icn}'";
                ctx.Database.ExecuteSqlCommand(query);
            }
        }

        // ─── Source DB check (verify ICN exists in old CliffsKFCWaffle table) ───

        public bool IcnExistsInSourceDb(string icn)
        {
            using (var ctx = new EIAutomationTeam02Entities())
            {
                return ctx.CliffsKFCWaffles.Any(k => k.ICN == icn);
            }
        }
    }

    // ─── Projection DTO ──────────────────────────────────────────────────────────

    public class RetryIcnRow
    {
        public string ICN          { get; set; }
        public string Engine       { get; set; }
        public string Office       { get; set; }
        public string OrgID        { get; set; }
        public string Locality     { get; set; }
        public int?   Priority_Flag { get; set; }
    }
}
