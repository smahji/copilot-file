using System;
using System.Net.Http;
using System.Text;
using Newtonsoft.Json;
using RestSharp;
using EWDRetryWPF.Models;

namespace EWDRetryWPF.Services
{
    /// <summary>
    /// Encapsulates all outbound HTTP calls to OGA/EWD endpoints.
    /// Mirrors CallOptumAPI, CallOgaAPI, and CallOptumAPIforAengine from the original codebase.
    /// </summary>
    public class ApiService
    {
        private readonly string _dateKey = DateTime.Now.ToString("yyyyMMdd");

        // Production endpoints (primary + fallback)
        private const string OptumPrd1 = "http://ewdrtng-srvcs-mprd1.optum.com/determineEligibilityAndSendToEWDIncrementPriority/";
        private const string OptumPrd2 = "http://ewdrtng-srvcs-mprd2.optum.com/determineEligibilityAndSendToEWDIncrementPriority/";
        private const string OgaUrl    = "https://eni-claims-dev.optum.com/load_data";

        /// <summary>
        /// Sends ICN to Optum REST endpoint (priority flag 2).
        /// Falls back to mprd2 if mprd1 returns non-OK.
        /// Returns true if final response is OK.
        /// </summary>
        public bool CallOptumAPI(string icn, string priorityFlag)
        {
            IRestResponse response = ExecuteOptumGet(OptumPrd1 + icn + "/" + priorityFlag, icn, useAEngineLog: false);

            if (response.StatusCode.ToString() != "OK")
                response = ExecuteOptumGet(OptumPrd2 + icn + "/" + priorityFlag, icn, useAEngineLog: false);

            return response.StatusCode.ToString() == "OK";
        }

        /// <summary>
        /// Sends A-engine ICN to Optum REST endpoint (priority flag 4).
        /// Same dual-endpoint fallback pattern as CallOptumAPI but writes to A-engine log.
        /// </summary>
        public bool CallOptumAPIforAEngine(string icn, string priorityFlag)
        {
            IRestResponse response = ExecuteOptumGet(OptumPrd1 + icn + "/" + priorityFlag, icn, useAEngineLog: true);

            if (response.StatusCode.ToString() != "OK")
                response = ExecuteOptumGet(OptumPrd2 + icn + "/" + priorityFlag, icn, useAEngineLog: true);

            return response.StatusCode.ToString() == "OK";
        }

        /// <summary>
        /// Sends ICN data to OGA load_data endpoint (priority flag 4 via JSON POST).
        /// Returns true if status is OK or body contains "Data already present in table".
        /// </summary>
        public bool CallOgaAPI(string reportingPool, string claimAge, string msid, IcnEntity icnObj)
        {
            try
            {
                using (var client = new HttpClient())
                {
                    var payload = new
                    {
                        office         = icnObj.Office?.Trim(),
                        claim_spec_desc = icnObj.OrgId?.Trim(),
                        reporting_pool = reportingPool,
                        icn            = icnObj.ICN,
                        pay_eng        = icnObj.Engine,
                        claim_age      = claimAge,
                        sites          = icnObj.Locality,
                        msid           = msid
                    };

                    string json    = JsonConvert.SerializeObject(payload);
                    var    content = new StringContent(json, Encoding.UTF8, "application/json");

                    HttpResponseMessage response     = client.PostAsync(OgaUrl, content).Result;
                    string              responseBody = response.Content.ReadAsStringAsync().Result;
                    string              statusCode   = response.StatusCode.ToString();

                    LogService.Log(LogService.BuildLine(icnObj.ICN, statusCode, responseBody), _dateKey);

                    return statusCode == "OK" || responseBody.Contains("Data already present in table");
                }
            }
            catch (Exception ex)
            {
                LogService.Log($"[OGA Exception] {icnObj.ICN}: {ex.Message}", _dateKey);
                return false;
            }
        }

        // ─── Helpers ─────────────────────────────────────────────────────────────

        private IRestResponse ExecuteOptumGet(string url, string icn, bool useAEngineLog)
        {
            var client  = new RestClient(url) { Timeout = -1 };
            var request = new RestRequest(Method.GET);
            request.AddHeader("Accept", "text/plain");

            IRestResponse response   = client.Execute(request);
            string        statusCode = response.StatusCode.ToString();
            string        logLine    = LogService.BuildLine(icn, statusCode, response.Content);

            if (useAEngineLog)
                LogService.LogAEngine(logLine, _dateKey);
            else
                LogService.Log(logLine, _dateKey);

            return response;
        }
    }
}
