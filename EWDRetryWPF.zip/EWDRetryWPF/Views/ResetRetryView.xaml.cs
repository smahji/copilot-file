using System.Windows.Controls;

namespace EWDRetryWPF.Views
{
    public partial class ResetRetryView : UserControl
    {
        public ResetRetryView() => InitializeComponent();
    }
}
