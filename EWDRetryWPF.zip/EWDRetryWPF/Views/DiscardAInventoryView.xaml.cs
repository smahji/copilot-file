using System.Windows.Controls;

namespace EWDRetryWPF.Views
{
    public partial class DiscardAInventoryView : UserControl
    {
        public DiscardAInventoryView() => InitializeComponent();
    }
}
