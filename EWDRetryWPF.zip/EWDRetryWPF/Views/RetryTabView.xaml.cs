using System.Windows.Controls;

namespace EWDRetryWPF.Views
{
    public partial class RetryTabView : UserControl
    {
        public RetryTabView() => InitializeComponent();
    }
}
