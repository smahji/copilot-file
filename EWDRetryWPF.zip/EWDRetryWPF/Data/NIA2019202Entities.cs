using System.Data.Entity;
using EWDRetryWPF.Models;

namespace EWDRetryWPF.Data
{
    /// <summary>
    /// DbContext for the NIA2019202 database — hosts CliffsKFCWaffles_Api and WCRPaymentLog_Api.
    /// Connection string key: "NIA2019202Entities" in App.config.
    /// </summary>
    public class NIA2019202Entities : DbContext
    {
        public NIA2019202Entities()
            : base("name=NIA2019202Entities") { }

        public virtual DbSet<CliffsKFCWaffles_Api> CliffsKFCWaffles_Api { get; set; }
        public virtual DbSet<WCRPaymentLog_Api>    WCRPaymentLog_Api     { get; set; }

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            // Map to the exact table names used in SQL Server
            modelBuilder.Entity<CliffsKFCWaffles_Api>().ToTable("CliffsKFCWaffles_Api");
            modelBuilder.Entity<WCRPaymentLog_Api>().ToTable("WCRPaymentLog_Api");
            base.OnModelCreating(modelBuilder);
        }
    }
}
