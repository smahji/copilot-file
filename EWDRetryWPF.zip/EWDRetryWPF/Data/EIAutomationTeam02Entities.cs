using System.Data.Entity;
using EWDRetryWPF.Models;

namespace EWDRetryWPF.Data
{
    /// <summary>
    /// DbContext for the EIAutomationTeam02 database — hosts CliffsKFCWaffle and WCRPaymentLog.
    /// Connection string key: "EIAutomationTeam02Entities" in App.config.
    /// </summary>
    public class EIAutomationTeam02Entities : DbContext
    {
        public EIAutomationTeam02Entities()
            : base("name=EIAutomationTeam02Entities") { }

        public virtual DbSet<CliffsKFCWaffle> CliffsKFCWaffles  { get; set; }
        public virtual DbSet<WCRPaymentLog>   WCRPaymentLogs     { get; set; }

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            modelBuilder.Entity<CliffsKFCWaffle>().ToTable("CliffsKFCWaffles");
            modelBuilder.Entity<WCRPaymentLog>().ToTable("WCRPaymentLog");
            base.OnModelCreating(modelBuilder);
        }
    }
}
