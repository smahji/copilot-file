using System;
using System.Collections.Generic;
using ORSResearchTool.Models;

namespace ORSResearchTool
{
    /// <summary>
    /// Orchestrates per-ORS navigation and date capture.
    /// The AS400Session is already connected and logged in when passed here —
    /// credential handling is done upstream (MainForm → DatabaseHelper → AS400Session).
    /// </summary>
    public class OrsResearcher
    {
        private readonly AS400Session _session;

        public event Action<string>   OnStatusUpdate;
        public event Action<int, int> OnProgress;

        public OrsResearcher(AS400Session session)
        {
            _session = session ?? throw new ArgumentNullException(nameof(session));
        }

        public List<OrsRecord> Research(IList<string> orsIds)
        {
            var results = new List<OrsRecord>();
            int total   = orsIds.Count;

            for (int i = 0; i < total; i++)
            {
                string orsId = orsIds[i].Trim();
                OnProgress?.Invoke(i + 1, total);
                OnStatusUpdate?.Invoke($"[{i + 1}/{total}] ORS: {orsId}");

                var record = new OrsRecord { OrsId = orsId };

                try
                {
                    if (!_session.OpenOrs(orsId))
                    {
                        record.Status     = "NA";
                        record.Difference = "NA";
                        results.Add(record);
                        OnStatusUpdate?.Invoke("  → Not found – skipped.");
                        SafeGoToMainMenu();
                        continue;
                    }

                    // Sent date: look for 224 → 007
                    string sentRaw = _session.FindSentDate();
                    if (sentRaw == null || !TryParseAs400Date(sentRaw, out DateTime sentDate))
                    {
                        record.Status = "NA"; record.Difference = "NA";
                        results.Add(record);
                        OnStatusUpdate?.Invoke("  → Sent date (224/007) not found – skipped.");
                        SafeGoToMainMenu();
                        continue;
                    }

                    // Received date: F7 then look for 007 → 224
                    string recvRaw = _session.FindReceivedDate();
                    if (recvRaw == null || !TryParseAs400Date(recvRaw, out DateTime recvDate))
                    {
                        record.Status = "NA"; record.Difference = "NA";
                        results.Add(record);
                        OnStatusUpdate?.Invoke("  → Received date (007/224) not found – skipped.");
                        SafeGoToMainMenu();
                        continue;
                    }

                    int diff = (int)(recvDate - sentDate).TotalDays;
                    record.SentDate     = sentDate;
                    record.ReceivedDate = recvDate;
                    record.Difference   = diff.ToString();
                    record.Status       = "Found";
                    OnStatusUpdate?.Invoke(
                        $"  → Sent: {sentDate:MM/dd/yyyy}  Recv: {recvDate:MM/dd/yyyy}  TAT: {diff}d");
                }
                catch (Exception ex)
                {
                    record.Status     = "Error";
                    record.Difference = "NA";
                    OnStatusUpdate?.Invoke($"  → ERROR: {ex.Message}");
                }

                results.Add(record);
                SafeGoToMainMenu();
            }

            return results;
        }

        private void SafeGoToMainMenu()
        {
            try { _session.GoToMainMenu(); } catch { /* best-effort */ }
        }

        // ── Date parsing — handles AS400 common formats ────────────────────────
        private static readonly string[] DATE_FORMATS =
        {
            "MM/dd/yy", "MM/dd/yyyy", "M/d/yy", "M/d/yyyy", "MMddyy", "MMddyyyy"
        };

        private static bool TryParseAs400Date(string raw, out DateTime result)
        {
            result = DateTime.MinValue;
            if (string.IsNullOrWhiteSpace(raw)) return false;

            raw = raw.Trim();
            foreach (var fmt in DATE_FORMATS)
                if (DateTime.TryParseExact(raw, fmt,
                    System.Globalization.CultureInfo.InvariantCulture,
                    System.Globalization.DateTimeStyles.None, out result))
                    return true;

            return DateTime.TryParse(raw, out result);
        }
    }
}
