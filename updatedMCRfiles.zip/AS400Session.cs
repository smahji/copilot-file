using System;
using System.Configuration;
using System.Threading;
using ORSResearchTool.Models;

// ── UnetHelper namespace — references mdlUnet and autECLPSObj exactly as in
//    UnetWrapper.vb / ClaimProcessor.vb from the Corrected Claim Reversal project.
// Make sure UnetHelper.dll is added as a project reference.

namespace ORSResearchTool
{
    // =========================================================================
    // UnetSession — mirrors Unet.UnetSession from UnetWrapper.vb
    // Tracks session state and inactivity timeout (5-minute rule).
    // =========================================================================
    internal class UnetSession
    {
        public string   SessionName      { get; }
        public string   PaylocID         { get; }
        public string   PaylocPassword   { get; }
        public bool     IsActive         { get; set; }
        public DateTime StartTime        { get; }
        public DateTime LastActivityTime { get; set; }

        public UnetSession(string sessionName, string paylocID, string paylocPassword)
        {
            SessionName      = sessionName.ToUpper();
            PaylocID         = paylocID;
            PaylocPassword   = paylocPassword;
            IsActive         = false;
            StartTime        = DateTime.Now;
            LastActivityTime = DateTime.Now;
        }

        /// <summary>Returns false if the session has been idle more than 5 minutes.</summary>
        public bool IsSessionAlive()
            => (DateTime.Now - LastActivityTime).TotalSeconds < 300;
    }

    // =========================================================================
    // AS400Session
    // Replaces the earlier placeholder stub.
    //
    // Key changes from the Corrected Claim Reversal architecture:
    //   1. No credentials passed via constructor.  They are fetched from the
    //      SecondaryDB DroidCred table (same pattern as DatabaseHelper.vb /
    //      ClaimProcessor.ProcessSingleClaim) and injected via
    //      SetCredential(locality) at runtime.
    //   2. UnetWrapper calls are aligned to the EXACT methods in UnetWrapper.vb:
    //        mdlUnet.InitializeEmulator  / mdlUnet.apiChk
    //        mdlUnet.SendKeyes           (note the typo in the DLL — "Keyes")
    //        mdlUnet.SendEnter / SendClear
    //        autECLPSObj.SendKeys("[PF7]") / "[PF8]" / "[PF9]"
    //        autECLPSObj.GetText(row, col, length)
    //        mdlUnet.GetTextRect(r1,c1,r2,c2)
    //   3. Payloc login follows the retry loop from VerifyClaimExists() in
    //      ClaimProcessor.vb: up to MAX_LOGIN_RETRIES attempts, checking row 24
    //      for "W018ADJ SIGN ON COMPLETE", restarting communication on failure.
    //   4. Session inactivity is tracked via UnetSession.LastActivityTime.
    //   5. App.config keys (UnetTimeout, UnetConnectionWait, UnetMaxRetries)
    //      are read via ConfigurationManager — same source as ConfigManager.vb.
    // =========================================================================
    public class AS400Session : IDisposable
    {
        // ── Internal session state ────────────────────────────────────────────
        private UnetSession _session;

        // ── Credential (injected from DB cache via SetCredential) ─────────────
        private DroidCredential _credential;

        // ── Locality selected by user (drives which DroidCred row is used) ────
        public string Locality { get; private set; }

        // ── Tunable delays read from App.config ───────────────────────────────
        private readonly int _connectionWaitMs; // UnetConnectionWait
        private readonly int _maxRetries;       // UnetMaxRetries

        // Overridable from UI (mirrors ActionDelayMs / PageScrollDelayMs in old stub)
        public int ActionDelayMs     { get; set; } = 500;
        public int PageScrollDelayMs { get; set; } = 300;

        private const int MAX_LOGIN_RETRIES = 3;

        // ── Screen coordinate constants ────────────────────────────────────────
        // FN field:  row 22, col 5, len 2
        private const int FN_ROW = 22;
        private const int FN_COL = 5;
        // ORS# field: row 24, col 7
        private const int ORS_ROW = 24;
        private const int ORS_COL = 7;
        // Off-ID columns in comment lines
        private const int OFFID1_COL = 9;    // "224"
        private const int OFFID2_COL = 25;   // "007"
        private const int DATE_COL   = 2;    // date on same row
        // Full-row reads
        private const int SCREEN_COLS = 80;
        private const int SCREEN_ROWS = 24;

        // Sentinel strings
        private const string SIGN_ON_OK    = "W018ADJ SIGN ON COMPLETE";
        private const string LAST_PAGE     = "LAST PAGE OF NON-SYSTEM COMMENTS";
        private const string MAIN_MENU     = "ONLINE ROUTING SYSTEM MAIN MENU";

        // ── Constructor ───────────────────────────────────────────────────────
        /// <param name="sessionName">
        ///   Emulator session name (e.g. "A", "B").
        ///   Passed to mdlUnet.InitializeEmulator — same as ClaimProcessor.
        /// </param>
        public AS400Session(string sessionName)
        {
            // Read tunable values from App.config (same keys as ConfigManager.vb)
            _connectionWaitMs = ParseAppSetting("UnetConnectionWait", 50);
            _maxRetries       = ParseAppSetting("UnetMaxRetries",      3);

            // Session object without credentials yet — they come from DB cache
            _session = new UnetSession(sessionName, string.Empty, string.Empty);
        }

        // ── Credential injection (call before Connect) ────────────────────────

        /// <summary>
        /// Injects the Payloc credential retrieved from the DroidCred cache.
        /// Must be called after the locality is selected and before Connect().
        /// Mirrors ClaimProcessor.ProcessSingleClaim step 3+4.
        /// </summary>
        public void SetCredential(DroidCredential credential, string locality)
        {
            _credential = credential ?? throw new ArgumentNullException(nameof(credential));
            Locality    = locality;

            // Rebuild UnetSession now that we have the real ID/Pass
            _session = new UnetSession(_session.SessionName, credential.ID, credential.Pass);
        }

        // ── Connection & login ────────────────────────────────────────────────

        /// <summary>
        /// Initialises the emulator and performs Payloc login.
        /// Mirrors UnetWrapper.InitializeEmulator + VerifyClaimExists login loop.
        /// </summary>
        public void Connect()
        {
            if (_credential == null)
                throw new InvalidOperationException(
                    "Call SetCredential() before Connect(). " +
                    "Payloc credentials must be loaded from the database first.");

            InitializeEmulator();
            PaylocLogin();
        }

        private void InitializeEmulator()
        {
            // Mirrors UnetWrapper.InitializeEmulator → mdlUnet.InitializeEmulator
            mdlUnet.InitializeEmulator(_session.SessionName);

            // Wait for communication — mirrors WaitForCommunication / apiChk pattern
            Thread.Sleep(_connectionWaitMs);
            mdlUnet.apiChk();
            _session.IsActive = true;
        }

        /// <summary>
        /// Payloc login with retry loop — ported directly from
        /// VerifyClaimExists() in ClaimProcessor.vb.
        /// Retries up to MAX_LOGIN_RETRIES times, restarting communication on
        /// each failure before throwing.
        /// </summary>
        private void PaylocLogin()
        {
            bool loginSuccess = false;
            int  loginCount   = 0;

            Thread.Sleep(500); // match the 500 ms pre-login pause from ClaimProcessor

            while (!loginSuccess)
            {
                // Call the global PaylocLogIn helper (same signature as ClaimProcessor.vb)
                PaylocLogIn(
                    engine:      string.Empty,   // not applicable for ORS tool
                    office:      string.Empty,
                    sessionName: _session.SessionName,
                    paylocID:    _credential.ID,
                    paylocPass:  _credential.Pass
                );

                string row24 = GetText(24, 1, 80);
                if (row24.Contains(SIGN_ON_OK))
                {
                    loginSuccess           = true;
                    _session.IsActive      = true;
                    _session.LastActivityTime = DateTime.Now;
                }
                else
                {
                    if (loginCount >= MAX_LOGIN_RETRIES)
                        throw new InvalidOperationException(
                            $"Payloc login failed after {MAX_LOGIN_RETRIES} attempts " +
                            $"for session {_session.SessionName}. " +
                            "Check that the UNET system is available.");

                    loginCount++;

                    // Restart communication — mirrors ClaimProcessor retry block
                    autECLPSObj.StartCommunication();
                    do
                    {
                        mdlUnet.apiChk();
                    } while (!autECLPSObj.CommStarted);

                    Thread.Sleep(60000); // 60 s cooldown — same as ClaimProcessor
                }
            }
        }

        // ── Public ORS navigation API (used by OrsResearcher) ─────────────────

        /// <summary>
        /// Navigates to the ORS comment screen via F9 → FN=34 → ORS# → Enter.
        /// Returns false if the screen shows an error (not found / invalid).
        /// </summary>
        public bool OpenOrs(string orsId)
        {
            SendF9();

            // Enter FN = 34
            mdlUnet.SendKeyes("34", FN_ROW, FN_COL);
            Thread.Sleep(100);
            mdlUnet.apiChk();

            // Enter ORS#
            mdlUnet.SendKeyes(orsId, ORS_ROW, ORS_COL);
            Thread.Sleep(100);
            mdlUnet.apiChk();

            mdlUnet.SendEnter();
            Thread.Sleep(ActionDelayMs);
            mdlUnet.apiChk();
            TouchActivity();

            string row1 = GetText(1, 1, SCREEN_COLS, trim: true);
            return !row1.Contains("NOT FOUND") &&
                   !row1.Contains("INVALID")   &&
                   !row1.Contains("ERROR");
        }

        /// <summary>
        /// Scans forward page-by-page (F8) for a line where off-id col 9 == "224"
        /// and off-id col 25 == "007".  Returns the date string from col 2, or null.
        /// </summary>
        public string FindSentDate()
            => ScanPages(targetId1: "224", targetId2: "007");

        /// <summary>
        /// Presses F7 once (per spec) then scans forward for
        /// off-id1 == "007" / off-id2 == "224" to capture received date.
        /// </summary>
        public string FindReceivedDate()
        {
            SendF7();
            return ScanPages(targetId1: "007", targetId2: "224");
        }

        /// <summary>
        /// Scrolls to the last page of comments then presses F2 to return to
        /// ONLINE ROUTING SYSTEM MAIN MENU.
        /// </summary>
        public void GoToMainMenu()
        {
            ScrollToLastPage();

            // F2 — return to main menu
            autECLPSObj.SendKeys("[PF2]");
            mdlUnet.apiChk();
            TouchActivity();

            // Wait up to ~5 s for main menu sentinel
            for (int i = 0; i < 10; i++)
            {
                if (GetText(1, 1, SCREEN_COLS, trim: true).Contains(MAIN_MENU))
                    break;
                Thread.Sleep(ActionDelayMs / 2);
            }
        }

        // ── Private navigation helpers ────────────────────────────────────────

        private string ScanPages(string targetId1, string targetId2)
        {
            const int MAX_PAGES = 500;

            for (int page = 0; page < MAX_PAGES; page++)
            {
                // Check every row on the current screen
                string hit = ScanCurrentScreen(targetId1, targetId2);
                if (hit != null) return hit;

                // Check for last-page sentinel on row 1
                if (GetText(1, 1, SCREEN_COLS, trim: true).Contains(LAST_PAGE))
                    return null;

                SendF8();
            }

            return null;
        }

        private string ScanCurrentScreen(string targetId1, string targetId2)
        {
            for (int row = 1; row <= SCREEN_ROWS; row++)
            {
                string id1 = GetText(row, OFFID1_COL, 3, trim: true);
                string id2 = GetText(row, OFFID2_COL, 3, trim: true);

                if (id1 == targetId1 && id2 == targetId2)
                    return GetText(row, DATE_COL, 10, trim: true);
            }
            return null;
        }

        private void ScrollToLastPage()
        {
            const int MAX_PAGES = 500;
            for (int i = 0; i < MAX_PAGES; i++)
            {
                if (GetText(1, 1, SCREEN_COLS, trim: true).Contains(LAST_PAGE))
                    break;
                SendF8();
            }
        }

        // ── Low-level key senders — aligned to UnetWrapper.vb exact calls ──────

        private void SendF7()
        {
            autECLPSObj.SendKeys("[PF7]");
            mdlUnet.apiChk();
            Thread.Sleep(PageScrollDelayMs);
            TouchActivity();
        }

        private void SendF8()
        {
            // Mirrors UnetWrapper.SendF8()
            autECLPSObj.SendKeys("[PF8]");
            mdlUnet.apiChk();
            Thread.Sleep(PageScrollDelayMs);
            TouchActivity();
        }

        private void SendF9()
        {
            // Mirrors UnetWrapper.SendF9()
            autECLPSObj.SendKeys("[PF9]");
            mdlUnet.apiChk();
            Thread.Sleep(ActionDelayMs);
            TouchActivity();
        }

        // ── Screen reading — aligned to UnetWrapper.vb exact calls ───────────

        /// <summary>
        /// Mirrors UnetWrapper.GetText → autECLPSObj.GetText(row, col, length).
        /// </summary>
        private string GetText(int row, int col, int length, bool trim = false)
        {
            try
            {
                string text = autECLPSObj.GetText(row, col, length) ?? string.Empty;
                TouchActivity();
                return trim ? text.Trim() : text;
            }
            catch
            {
                return string.Empty;
            }
        }

        /// <summary>
        /// Mirrors UnetWrapper.GetTextRect → mdlUnet.GetTextRect.
        /// </summary>
        public string GetTextRect(int startRow, int startCol, int endRow, int endCol)
        {
            try
            {
                string text = mdlUnet.GetTextRect(startRow, startCol, endRow, endCol) ?? string.Empty;
                TouchActivity();
                return text;
            }
            catch
            {
                return string.Empty;
            }
        }

        // ── Session management ────────────────────────────────────────────────

        private void TouchActivity()
        {
            _session.LastActivityTime = DateTime.Now;
        }

        /// <summary>
        /// Mirrors UnetWrapper.CloseSession — sends two CLEARs then marks inactive.
        /// </summary>
        public void CloseSession()
        {
            try
            {
                mdlUnet.SendClear();
                mdlUnet.SendClear();
            }
            catch { /* best-effort */ }
            finally
            {
                _session.IsActive = false;
            }
        }

        public void Dispose() => CloseSession();

        // ── App.config helper ─────────────────────────────────────────────────

        private static int ParseAppSetting(string key, int fallback)
        {
            string val = ConfigurationManager.AppSettings[key];
            return int.TryParse(val, out int parsed) ? parsed : fallback;
        }
    }
}
