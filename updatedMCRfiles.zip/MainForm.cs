using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using ORSResearchTool.Database;
using ORSResearchTool.Models;

namespace ORSResearchTool
{
    public class MainForm : Form
    {
        // ── Controls ──────────────────────────────────────────────────────────
        private Label         lblInputFile;
        private TextBox       txtInputFile;
        private Button        btnBrowseInput;

        private Label         lblOutputFile;
        private TextBox       txtOutputFile;
        private Button        btnBrowseOutput;

        private GroupBox      grpConnection;
        private Label         lblSession;
        private TextBox       txtSession;
        private Label         lblLocality;
        private ComboBox      cmbLocality;          // ← Locality dropdown
        private Label         lblCredStatus;        // shows credential fetch result

        private Label         lblDelayAction;
        private NumericUpDown nudActionDelay;
        private Label         lblDelayScroll;
        private NumericUpDown nudScrollDelay;

        private Button        btnLoadCredentials;   // explicit credential prefetch
        private Button        btnStart;
        private Button        btnCancel;

        private ProgressBar   progressBar;
        private Label         lblProgress;
        private RichTextBox   rtbLog;

        // ── State ─────────────────────────────────────────────────────────────
        private bool                                _running;
        private CancellationTokenSource             _cts;
        private Dictionary<string, DroidCredential> _credCache;  // loaded from DB once

        public MainForm()
        {
            InitializeComponent();
        }

        // ── UI construction ───────────────────────────────────────────────────
        private void InitializeComponent()
        {
            Text            = "ORS Research Tool";
            Size            = new Size(700, 660);
            FormBorderStyle = FormBorderStyle.FixedDialog;
            MaximizeBox     = false;
            StartPosition   = FormStartPosition.CenterScreen;
            Font            = new Font("Arial", 9f);

            int y = 12;

            // Input file
            lblInputFile   = new Label  { Text = "Input Excel File:",  Left = 12,  Top = y,     Width = 120, AutoSize = false };
            txtInputFile   = new TextBox { Left = 135, Top = y - 2, Width = 440, ReadOnly = true };
            btnBrowseInput = new Button { Text = "Browse…",            Left = 582, Top = y - 2, Width = 80  };
            btnBrowseInput.Click += BtnBrowseInput_Click;
            y += 30;

            // Output file
            lblOutputFile   = new Label  { Text = "Output Excel File:", Left = 12,  Top = y,     Width = 120, AutoSize = false };
            txtOutputFile   = new TextBox { Left = 135, Top = y - 2, Width = 440 };
            btnBrowseOutput = new Button { Text = "Browse…",            Left = 582, Top = y - 2, Width = 80  };
            btnBrowseOutput.Click += BtnBrowseOutput_Click;
            y += 36;

            // ── Connection group ──────────────────────────────────────────────
            grpConnection = new GroupBox
            {
                Text = "Session & Credentials (from DB)", Left = 10, Top = y, Width = 660, Height = 145
            };

            // Session name
            lblSession = new Label  { Text = "Session Name:", Left = 10, Top = 22, Width = 110, AutoSize = false, Parent = grpConnection };
            txtSession = new TextBox { Left = 125, Top = 20, Width = 80, Text = "A", Parent = grpConnection };

            // ── Locality dropdown ─────────────────────────────────────────────
            lblLocality = new Label
            {
                Text      = "Locality:",
                Left      = 230, Top = 22, Width = 65,
                AutoSize  = false,
                Parent    = grpConnection
            };
            cmbLocality = new ComboBox
            {
                Left          = 300, Top = 19, Width = 160,
                DropDownStyle = ComboBoxStyle.DropDownList,
                Parent        = grpConnection
            };
            cmbLocality.Items.Add(LocalityConstants.Domestic);   // "Domestic"
            cmbLocality.Items.Add(LocalityConstants.Global);      // "Global"
            cmbLocality.SelectedIndex = 0;                        // default: Domestic
            cmbLocality.SelectedIndexChanged += CmbLocality_Changed;

            // Credential status label
            lblCredStatus = new Label
            {
                Text      = "Credentials not loaded.",
                Left      = 10, Top = 50, Width = 630,
                AutoSize  = false,
                ForeColor = Color.Gray,
                Parent    = grpConnection
            };

            // Delays
            lblDelayAction = new Label { Text = "Action delay (ms):", Left = 10,  Top = 78, Width = 130, AutoSize = false, Parent = grpConnection };
            nudActionDelay = new NumericUpDown { Left = 145, Top = 76, Width = 70, Minimum = 100, Maximum = 5000, Value = 500, Parent = grpConnection };

            lblDelayScroll = new Label { Text = "Scroll delay (ms):", Left = 245, Top = 78, Width = 130, AutoSize = false, Parent = grpConnection };
            nudScrollDelay = new NumericUpDown { Left = 380, Top = 76, Width = 70, Minimum = 100, Maximum = 3000, Value = 300, Parent = grpConnection };

            // Load credentials button
            btnLoadCredentials = new Button
            {
                Text   = "Load Credentials from DB",
                Left   = 10, Top = 108, Width = 200, Height = 26,
                Parent = grpConnection
            };
            btnLoadCredentials.Click += BtnLoadCredentials_Click;

            y += grpConnection.Height + 10;

            // ── Action buttons ────────────────────────────────────────────────
            btnStart  = new Button { Text = "▶  Start Research", Left = 12,  Top = y, Width = 165, Height = 30 };
            btnCancel = new Button { Text = "■  Cancel",          Left = 185, Top = y, Width = 100, Height = 30, Enabled = false };
            btnStart.Click  += BtnStart_Click;
            btnCancel.Click += BtnCancel_Click;
            y += 40;

            // ── Progress ──────────────────────────────────────────────────────
            progressBar = new ProgressBar { Left = 12, Top = y, Width = 660, Height = 18 };
            y += 24;
            lblProgress = new Label { Left = 12, Top = y, Width = 660, AutoSize = false, Text = "Ready." };
            y += 22;

            // ── Log ───────────────────────────────────────────────────────────
            rtbLog = new RichTextBox
            {
                Left       = 12, Top = y, Width = 660, Height = 120,
                ReadOnly   = true,
                BackColor  = Color.Black,
                ForeColor  = Color.LimeGreen,
                Font       = new Font("Consolas", 8.5f),
                ScrollBars = RichTextBoxScrollBars.Vertical
            };

            Controls.AddRange(new Control[]
            {
                lblInputFile, txtInputFile, btnBrowseInput,
                lblOutputFile, txtOutputFile, btnBrowseOutput,
                grpConnection,
                btnStart, btnCancel,
                progressBar, lblProgress,
                rtbLog
            });
        }

        // ── Browse ────────────────────────────────────────────────────────────

        private void BtnBrowseInput_Click(object sender, EventArgs e)
        {
            using (var dlg = new OpenFileDialog
            {
                Title  = "Select Input Excel File",
                Filter = "Excel Files (*.xlsx;*.xlsm)|*.xlsx;*.xlsm|All Files|*.*"
            })
            {
                if (dlg.ShowDialog() != DialogResult.OK) return;
                txtInputFile.Text = dlg.FileName;
                if (string.IsNullOrWhiteSpace(txtOutputFile.Text))
                {
                    string dir  = Path.GetDirectoryName(dlg.FileName);
                    string name = Path.GetFileNameWithoutExtension(dlg.FileName);
                    txtOutputFile.Text = Path.Combine(dir, $"{name}_Results.xlsx");
                }
            }
        }

        private void BtnBrowseOutput_Click(object sender, EventArgs e)
        {
            using (var dlg = new SaveFileDialog
            {
                Title      = "Save Output Excel File",
                Filter     = "Excel Files (*.xlsx)|*.xlsx",
                DefaultExt = "xlsx"
            })
            {
                if (dlg.ShowDialog() == DialogResult.OK)
                    txtOutputFile.Text = dlg.FileName;
            }
        }

        // ── Locality dropdown changed ─────────────────────────────────────────

        private void CmbLocality_Changed(object sender, EventArgs e)
        {
            // If the cache is already loaded, validate the selected locality exists
            if (_credCache != null)
                UpdateCredentialStatusLabel();
        }

        // ── Load credentials ──────────────────────────────────────────────────

        private async void BtnLoadCredentials_Click(object sender, EventArgs e)
        {
            btnLoadCredentials.Enabled = false;
            lblCredStatus.ForeColor    = Color.DarkGoldenrod;
            lblCredStatus.Text         = "Connecting to SecondaryDB (Wipro_Corrected_Droid)…";

            try
            {
                _credCache = await Task.Run(() =>
                {
                    var db = new DatabaseHelper();
                    return db.FetchAllCredentials();
                });

                AppendLog($"Credentials loaded: {_credCache.Count} localities found.");
                UpdateCredentialStatusLabel();
            }
            catch (Exception ex)
            {
                lblCredStatus.ForeColor = Color.Red;
                lblCredStatus.Text      = "Failed to load credentials: " + ex.Message;
                AppendLog("ERROR loading credentials: " + ex.Message);
            }
            finally
            {
                btnLoadCredentials.Enabled = true;
            }
        }

        private void UpdateCredentialStatusLabel()
        {
            if (_credCache == null) return;

            string locality = cmbLocality.SelectedItem?.ToString() ?? string.Empty;

            if (_credCache.ContainsKey(locality))
            {
                var cred = _credCache[locality];
                lblCredStatus.ForeColor = Color.DarkGreen;
                lblCredStatus.Text      =
                    $"✔  Credential loaded for '{locality}'  —  " +
                    $"Payloc ID: {cred.ID}  |  {_credCache.Count} locality records in cache.";
            }
            else
            {
                lblCredStatus.ForeColor = Color.Red;
                lblCredStatus.Text      =
                    $"✘  No credential found for locality '{locality}' in DroidCred table.";
            }
        }

        // ── Start / Cancel ────────────────────────────────────────────────────

        private async void BtnStart_Click(object sender, EventArgs e)
        {
            if (!ValidateInputs()) return;

            string locality = cmbLocality.SelectedItem?.ToString() ?? string.Empty;
            var    cred     = _credCache[locality];

            SetRunning(true);
            AppendLog($"=== ORS Research Started — Locality: {locality} ===");
            AppendLog($"Payloc ID: {cred.ID}  Session: {txtSession.Text.Trim().ToUpper()}");

            _cts = new CancellationTokenSource();

            List<OrsRecord> results = null;

            try
            {
                // Read ORS IDs (fast — stays on UI thread)
                var orsIds = ExcelHandler.ReadOrsIds(txtInputFile.Text);
                AppendLog($"Loaded {orsIds.Count} ORS IDs from input file.");
                progressBar.Maximum = orsIds.Count;
                progressBar.Value   = 0;

                string sessionName = txtSession.Text.Trim().ToUpper();
                int    actionDelay = (int)nudActionDelay.Value;
                int    scrollDelay = (int)nudScrollDelay.Value;

                results = await Task.Run(() =>
                {
                    // Build session — no credentials in constructor, injected from DB cache
                    var session = new AS400Session(sessionName)
                    {
                        ActionDelayMs     = actionDelay,
                        PageScrollDelayMs = scrollDelay
                    };

                    // Inject credential fetched from DroidCred — mirrors ClaimProcessor step 3+4
                    session.SetCredential(cred, locality);
                    session.Connect();   // InitializeEmulator + PaylocLogin (with retry loop)

                    var researcher = new OrsResearcher(session);

                    researcher.OnStatusUpdate += msg =>
                        BeginInvoke(new Action(() => AppendLog(msg)));

                    researcher.OnProgress += (cur, tot) =>
                        BeginInvoke(new Action(() =>
                        {
                            progressBar.Value = cur;
                            lblProgress.Text  = $"Processing {cur} of {tot}…";
                        }));

                    var res = researcher.Research(orsIds);
                    session.Dispose();
                    return res;

                }, _cts.Token);

                ExcelHandler.WriteResults(txtOutputFile.Text, results);
                AppendLog($"=== Done! Output → {txtOutputFile.Text} ===");
                lblProgress.Text = $"Completed. {results.Count} records written.";

                MessageBox.Show(
                    $"Research complete!\n\nLocality       : {locality}\n" +
                    $"Records        : {results.Count}\nOutput file    : {txtOutputFile.Text}",
                    "Done", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (OperationCanceledException)
            {
                AppendLog("=== Research cancelled. ===");
                lblProgress.Text = "Cancelled.";
            }
            catch (Exception ex)
            {
                AppendLog($"FATAL ERROR: {ex.Message}");
                // Mirror ClaimProcessor: show explicit message for Payloc failure
                if (ex.Message.Contains("Payloc login failed"))
                    MessageBox.Show("Payloc login failed.\nUNET system may not be available.",
                        "Login Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                else
                    MessageBox.Show("An error occurred:\n\n" + ex.Message,
                        "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                SetRunning(false);
            }
        }

        private void BtnCancel_Click(object sender, EventArgs e)
        {
            if (!_running) return;
            _cts?.Cancel();
            AppendLog("Cancellation requested — finishing current ORS…");
            btnCancel.Enabled = false;
        }

        // ── Validation ────────────────────────────────────────────────────────

        private bool ValidateInputs()
        {
            if (string.IsNullOrWhiteSpace(txtInputFile.Text) || !File.Exists(txtInputFile.Text))
            {
                MessageBox.Show("Please select a valid input Excel file.", "Validation",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return false;
            }
            if (string.IsNullOrWhiteSpace(txtOutputFile.Text))
            {
                MessageBox.Show("Please specify an output file path.", "Validation",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return false;
            }
            if (string.IsNullOrWhiteSpace(txtSession.Text))
            {
                MessageBox.Show("Please enter a session name (e.g. A).", "Validation",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return false;
            }
            if (_credCache == null || _credCache.Count == 0)
            {
                MessageBox.Show("Please load credentials from the database first.",
                    "Validation", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return false;
            }
            string locality = cmbLocality.SelectedItem?.ToString() ?? string.Empty;
            if (!_credCache.ContainsKey(locality))
            {
                MessageBox.Show(
                    $"No credential found for locality '{locality}' in the DroidCred table.\n" +
                    "Please reload credentials or select a different locality.",
                    "Validation", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return false;
            }
            return true;
        }

        // ── Helpers ───────────────────────────────────────────────────────────

        private void SetRunning(bool running)
        {
            _running                    = running;
            btnStart.Enabled            = !running;
            btnCancel.Enabled           = running;
            btnBrowseInput.Enabled      = !running;
            btnBrowseOutput.Enabled     = !running;
            btnLoadCredentials.Enabled  = !running;
            cmbLocality.Enabled         = !running;
            grpConnection.Enabled       = !running; // disables child controls too
        }

        private void AppendLog(string message)
        {
            if (rtbLog.InvokeRequired)
            {
                rtbLog.BeginInvoke(new Action<string>(AppendLog), message);
                return;
            }
            rtbLog.AppendText($"[{DateTime.Now:HH:mm:ss}] {message}\n");
            rtbLog.ScrollToCaret();
        }
    }
}
