using System;

namespace ORSResearchTool.Models
{
    /// <summary>
    /// Maps to the DroidCred table in SecondaryDB (Wipro_Corrected_Droid).
    /// Fetched once at startup and cached — mirrors the architecture in DatabaseHelper.vb.
    /// </summary>
    public class DroidCredential
    {
        public string ID       { get; set; }   // Payloc login ID
        public string Pass     { get; set; }   // Payloc password
        public string Locality { get; set; }   // "Global" | "Domestic"
    }

    /// <summary>
    /// Locality constants — kept in sync with Configuration.Constants in ConfigManager.vb.
    /// </summary>
    public static class LocalityConstants
    {
        public const string Global   = "Global";
        public const string Domestic = "Domestic";
    }
}
