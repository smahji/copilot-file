using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using ORSResearchTool.Models;

namespace ORSResearchTool.Database
{
    // =====================================================================
    // ConnectionManager — mirrors ConnectionManager.vb
    // Reads connection strings from App.config (PrimaryDB / SecondaryDB)
    // =====================================================================
    public class ConnectionManager
    {
        private readonly string _primaryConnStr;
        private readonly string _secondaryConnStr;

        public ConnectionManager()
        {
            _primaryConnStr   = ConfigurationManager.ConnectionStrings["PrimaryDB"]?.ConnectionString
                                ?? throw new InvalidOperationException("PrimaryDB connection string not found in App.config");
            _secondaryConnStr = ConfigurationManager.ConnectionStrings["SecondaryDB"]?.ConnectionString
                                ?? throw new InvalidOperationException("SecondaryDB connection string not found in App.config");
        }

        /// <summary>Primary DB: EIAutomationTeam02</summary>
        public SqlConnection GetPrimaryConnection()   => new SqlConnection(_primaryConnStr);

        /// <summary>Secondary DB: Wipro_Corrected_Droid (holds DroidCred table)</summary>
        public SqlConnection GetSecondaryConnection() => new SqlConnection(_secondaryConnStr);
    }

    // =====================================================================
    // DatabaseHelper — mirrors DatabaseHelper.vb
    // =====================================================================
    public class DatabaseHelper
    {
        private readonly ConnectionManager _connManager;

        public DatabaseHelper()
        {
            _connManager = new ConnectionManager();
        }

        /// <summary>
        /// Fetches all rows from DroidCred on SecondaryDB and returns a
        /// Dictionary keyed by Locality ("Global" / "Domestic").
        /// Call ONCE at startup and cache — mirrors FetchAllCredentials() in VB.
        /// </summary>
        public Dictionary<string, DroidCredential> FetchAllCredentials()
        {
            var dict = new Dictionary<string, DroidCredential>(StringComparer.OrdinalIgnoreCase);

            const string sql = "SELECT ID, Pass, Locality FROM DroidCred";

            using (var conn = _connManager.GetSecondaryConnection())
            using (var cmd  = new SqlCommand(sql, conn) { CommandTimeout = 30 })
            {
                conn.Open();
                using (var reader = cmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        var cred = new DroidCredential
                        {
                            ID       = reader["ID"].ToString().Trim(),
                            Pass     = reader["Pass"].ToString().Trim(),
                            Locality = reader["Locality"].ToString().Trim()
                        };

                        if (!dict.ContainsKey(cred.Locality))
                            dict[cred.Locality] = cred;
                    }
                }
            }

            return dict;
        }

        /// <summary>
        /// Retrieves a single credential from the cached dictionary.
        /// No DB round-trip — mirrors GetCredentialFromCache() in VB.
        /// </summary>
        public DroidCredential GetCredentialFromCache(
            Dictionary<string, DroidCredential> cache, string locality)
        {
            if (cache == null)
                throw new ArgumentNullException(nameof(cache));

            return cache.TryGetValue(locality, out var cred) ? cred : null;
        }
    }
}
